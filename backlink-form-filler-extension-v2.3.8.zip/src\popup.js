// ── State ─────────────────────────────────────────────────────────────────────

let activeProfile = null;
// Last email typed on extension login gate (survives popup close; password is never stored).
const STORAGE_AUTH_EMAIL_DRAFT = 'authGateEmailDraft';
// AUTH_SITE_BASE + AUTH_API_BASE: src/authConfig.js (loaded before this file in popup.html)

// ── Storage helpers ───────────────────────────────────────────────────────────

function getSettings(cb) {
  chrome.storage.local.get('settings', d => cb(d.settings || {}));
}

function saveSettings(settings, cb) {
  chrome.storage.local.set({ settings }, cb);
}

function saveActiveProfile(profile) {
  chrome.storage.local.set({ activeProfile: profile, activeProfileForSite: null });
}

function loadActiveProfile(cb) {
  chrome.storage.local.get('activeProfile', d => cb(d.activeProfile || null));
}

function setSiteAndActiveProfile(siteKey, profile, cb) {
  chrome.storage.local.get('siteProfiles', d => {
    const sp = d.siteProfiles || {};
    if (siteKey) sp[siteKey] = profile;
    chrome.storage.local.set({
      siteProfiles: sp,
      activeProfile: profile,
      activeProfileForSite: siteKey || null
    }, cb);
  });
}

function loadActiveProfileForCurrentTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (!tabs[0] || !tabs[0].url) {
      loadActiveProfile(saved => {
        activeProfile = saved;
        renderProfile(activeProfile);
      });
      return;
    }
    let u;
    try {
      u = new URL(tabs[0].url);
    } catch (e) {
      loadActiveProfile(saved => {
        activeProfile = saved;
        renderProfile(activeProfile);
      });
      return;
    }
    if (!u.protocol.startsWith('http')) {
      loadActiveProfile(saved => {
        activeProfile = saved;
        renderProfile(activeProfile);
      });
      return;
    }
    const sk = normalizeSiteKey(u.hostname);
    chrome.storage.local.get(['siteProfiles', 'activeProfile', 'activeProfileForSite'], d => {
      if (d.siteProfiles && d.siteProfiles[sk]) {
        activeProfile = d.siteProfiles[sk];
        renderProfile(activeProfile);
        return;
      }
      const ap = d.activeProfile || null;
      const aps = d.activeProfileForSite;
      if (ap) {
        if (aps == null) {
          activeProfile = ap;
          renderProfile(activeProfile);
          return;
        }
        if (aps === sk) {
          activeProfile = ap;
          renderProfile(activeProfile);
          return;
        }
      }
      activeProfile = null;
      renderProfile(null);
    });
  });
}

function saveQueriesState(state, cb) {
  chrome.storage.local.set({ queriesState: state }, cb);
}

function loadQueriesState(cb) {
  chrome.storage.local.get('queriesState', d => cb(d.queriesState || null));
}

function loadCommentState(cb) {
  chrome.storage.local.get('commentState', d => cb(d.commentState || null));
}

function patchCommentState(partial, cb) {
  chrome.storage.local.get('commentState', d => {
    const next = Object.assign({}, d.commentState || {}, partial);
    chrome.storage.local.set({ commentState: next }, cb);
  });
}

// ── Profile preview renderer ──────────────────────────────────────────────────

function renderProfile(profile) {
  const box = document.getElementById('profilePreview');
  if (!profile) {
    box.innerHTML = '<div style="text-align:center;color:#aaa;padding:20px 0;font-size:12px;">Press "Generate New Profile" to start</div>';
    return;
  }

  const rows = [
    ['First Name',  profile.firstName],
    ['Last Name',   profile.lastName],
    ['Full Name',   profile.fullName],
    ['Username',    profile.username],
    ['Email',       profile.email],
    ['Password',    `<span class="pwd-box">${profile.password}</span>`],
    ['Website',     profile.website || '—'],
    ['Address',     profile.addressLine1 || '—'],
    ['Address 2',   profile.addressLine2 || '—'],
    ['City',        profile.city || '—'],
    ['State / region', profile.stateRegion || '—'],
    ['Postal / ZIP', profile.postalCode || '—'],
    ['VMP / model', profile.vmp || '—'],
    ['Country',     profile.country],
    ['Date of birth', (profile.dobIso || (profile.birthDay != null ? `${profile.birthDay}/${profile.birthMonth}/${profile.birthYear}` : '—'))],
  ];

  box.innerHTML = rows.map(([k, v]) => `
    <div class="row">
      <span class="key">${k}</span>
      <span class="val">${v}</span>
    </div>
  `).join('');
}

// ── Status helper ─────────────────────────────────────────────────────────────

function showStatus(id, msg, type = 'info') {
  const el = document.getElementById(id);
  el.textContent = msg;
  el.className = 'status ' + type;
  setTimeout(() => el.className = 'status', 3000);
}

// ── Tabs ──────────────────────────────────────────────────────────────────────

function switchTab(name) {
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.id === 'tab-' + name));
}

// ── Init ──────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  const gate = document.getElementById('authGate');
  const trialGate = document.getElementById('trialEndGate');
  const appMain = document.getElementById('appMain');

  function hideAllGates() {
    gate.style.display = 'none';
    trialGate.style.display = 'none';
    appMain.style.display = 'none';
  }

  chrome.storage.local.get('accountAuthSession', async (d) => {
    const s = d.accountAuthSession;
    hideAllGates();

    if (!s || !s.token) {
      gate.style.display = 'flex';
      initAuthGate();
      return;
    }

    const me = await fetchMe(s.token, 3200);

    if (me && me.ok && me.user && me.user.email) {
      const sub =
        me.user.subscription_active === undefined || Number(me.user.subscription_active) === 1 ? 1 : 0;
      chrome.storage.local.set({
        accountAuthSession: {
          token: s.token,
          email: me.user.email,
          plan: me.user.plan || 'free',
          subscription_active: sub,
          at: Date.now()
        }
      });
      if (sub === 0) {
        trialGate.style.display = 'flex';
        initTrialEndGate();
        return;
      }
      appMain.style.display = 'block';
      initAuthenticatedApp();
      return;
    }

    if (me && me.error && /invalid token|missing bearer token|account disabled|account suspended/i.test(String(me.error))) {
      chrome.storage.local.remove('accountAuthSession', () => location.reload());
      return;
    }

    if (Number(s.subscription_active) === 0) {
      trialGate.style.display = 'flex';
      initTrialEndGate();
      return;
    }

    appMain.style.display = 'block';
    initAuthenticatedApp();
  });
});

let trialEndGateInited = false;
function initTrialEndGate() {
  if (trialEndGateInited) return;
  trialEndGateInited = true;

  const payLink = document.getElementById('trialPaymentLink');
  if (payLink) payLink.href = AUTH_SITE_BASE + '/payment/';

  document.getElementById('btnTrialRecheck').addEventListener('click', async () => {
    const { accountAuthSession } = await chrome.storage.local.get('accountAuthSession');
    if (!accountAuthSession || !accountAuthSession.token) {
      location.reload();
      return;
    }
    const me = await fetchMe(accountAuthSession.token, 5000);
    if (me && me.ok && me.user && me.user.email) {
      const sub =
        me.user.subscription_active === undefined || Number(me.user.subscription_active) === 1 ? 1 : 0;
      if (sub === 1) {
        chrome.storage.local.set(
          {
            accountAuthSession: {
              token: accountAuthSession.token,
              email: me.user.email,
              plan: me.user.plan || 'free',
              subscription_active: 1,
              at: Date.now()
            }
          },
          () => location.reload()
        );
        return;
      }
    }
  });

  document.getElementById('btnTrialSignOut').addEventListener('click', () => {
    chrome.storage.local.remove('accountAuthSession', () => location.reload());
  });
}

function initAuthGate() {
  const createLink = document.getElementById('createAccountLink');
  if (createLink) createLink.href = AUTH_SITE_BASE + '/';

  const emailEl = document.getElementById('authEmail');
  if (emailEl) {
    chrome.storage.local.get([STORAGE_AUTH_EMAIL_DRAFT], (r) => {
      const v = String(r[STORAGE_AUTH_EMAIL_DRAFT] || '').trim();
      if (v && !emailEl.value.trim()) {
        emailEl.value = v;
      }
    });
    emailEl.addEventListener('input', () => {
      const t = emailEl.value.trim().toLowerCase();
      chrome.storage.local.set({ [STORAGE_AUTH_EMAIL_DRAFT]: t });
    });
  }

  document.getElementById('btnAccountLogin').addEventListener('click', async () => {
    const errEl = document.getElementById('authGateError');
    errEl.style.display = 'none';
    errEl.textContent = '';
    const email = (document.getElementById('authEmail').value || '').trim().toLowerCase();
    const password = document.getElementById('authPassword').value || '';
    if (!email || !password) {
      errEl.textContent = 'Email aur password required.';
      errEl.style.display = 'block';
      return;
    }
    try {
      const r = await fetch(AUTH_API_BASE + '/login.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const d = await r.json();
      if (!r.ok || !d || !d.token) {
        errEl.textContent = (d && d.error) ? d.error : 'Login failed';
        errEl.style.display = 'block';
        return;
      }
      const sub =
        d.subscription_active === undefined || Number(d.subscription_active) === 1 ? 1 : 0;
      chrome.storage.local.set(
        {
          accountAuthSession: {
            token: d.token,
            email: d.email || email,
            plan: d.plan || 'free',
            subscription_active: sub,
            at: Date.now()
          },
          [STORAGE_AUTH_EMAIL_DRAFT]: email
        },
        () => location.reload()
      );
    } catch (_) {
      errEl.textContent = 'Login API error. Domain/API check karein.';
      errEl.style.display = 'block';
    }
  });
}

async function fetchMe(token, timeoutMs = 2500) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(AUTH_API_BASE + '/me.php', {
      method: 'GET',
      headers: { Authorization: 'Bearer ' + token },
      signal: ctrl.signal
    });
    clearTimeout(t);
    return await r.json();
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

function initAuthenticatedApp() {

  // Load saved settings
  getSettings(s => {
    document.getElementById('s_email').value = s.email || '';
    document.getElementById('s_website').value = s.website || '';
  });

  // Match profile to the active tab's site (per-site) + Fill tab hint
  loadActiveProfileForCurrentTab();

  chrome.storage.local.get('autoFillOnPage', d => {
    const el = document.getElementById('optAutoFill');
    if (el) el.checked = d.autoFillOnPage !== false;
  });
  const optAutoFill = document.getElementById('optAutoFill');
  if (optAutoFill) {
    optAutoFill.addEventListener('change', e => {
      chrome.storage.local.set({ autoFillOnPage: e.target.checked });
    });
  }

  // Tab switching + remember last tab (popup close/reopen)
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      switchTab(tab.dataset.tab);
      chrome.storage.local.set({ uiState: { activeTab: tab.dataset.tab } });
    });
  });

  chrome.storage.local.get('uiState', d => {
    let t = d.uiState && d.uiState.activeTab;
    if (t === 'inbox') t = 'queries';
    if (t && document.querySelector(`.tab[data-tab="${t}"]`)) switchTab(t);
  });

  // Generate button (saves to this site + will auto-reuse for sign-in on same site)
  document.getElementById('btnGenerate').addEventListener('click', () => {
    getSettings(s => {
      if (!s.email) {
        showStatus('fillStatus', '⚠ Set your email in Settings first', 'error');
        return;
      }
      activeProfile = generateProfile(s.email, s.website || '');
      const done = (msg) => {
        renderProfile(activeProfile);
        showStatus('fillStatus', msg, 'success');
      };
      chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
        if (!tabs[0] || !tabs[0].url) {
          saveActiveProfile(activeProfile);
          return done('✓ New profile — open a website tab to tie it to a site');
        }
        let u;
        try {
          u = new URL(tabs[0].url);
        } catch (e) {
          saveActiveProfile(activeProfile);
          return done('✓ New profile saved (could not read current tab URL)');
        }
        if (!u.protocol.startsWith('http')) {
          saveActiveProfile(activeProfile);
          return done('✓ New profile — use a normal http(s) page to save per-site');
        }
        setSiteAndActiveProfile(normalizeSiteKey(u.hostname), activeProfile, () => {
          done('✓ New profile for this site (auto-fill + same details on return)');
        });
      });
    });
  });

  // Fill button
  document.getElementById('btnFill').addEventListener('click', () => {
    if (!activeProfile) {
      showStatus('fillStatus', '⚠ Generate a profile first', 'error');
      return;
    }
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (!tabs[0]) {
        showStatus('fillStatus', '⚠ No active tab', 'error');
        return;
      }
      const tab = tabs[0];
      let siteKey = null;
      if (tab.url) {
        try {
          const u = new URL(tab.url);
          if (u.protocol.startsWith('http')) siteKey = normalizeSiteKey(u.hostname);
        } catch (e) { /* ignore */ }
      }
      const sk = siteKey;
      chrome.tabs.sendMessage(tab.id, { action: 'fillForm', profile: activeProfile }, response => {
        if (chrome.runtime.lastError || !response) {
          showStatus('fillStatus', '⚠ Could not reach page — try refreshing', 'error');
          return;
        }
        if (response.error === 'auth_required') {
          showStatus('fillStatus', '⚠ Pehle account login karein.', 'error');
          return;
        }
        if (response.error === 'subscription_inactive') {
          showStatus('fillStatus', '⚠ Trial End — open extension popup (199 PKR / month).', 'error');
          return;
        }
        const n = response.filled || 0;
        if (sk && n > 0) {
          setSiteAndActiveProfile(sk, activeProfile, () => {
            showStatus('fillStatus', `✓ Filled ${n} field${n !== 1 ? 's' : ''} (saved for this site)`, 'success');
          });
        } else {
          showStatus('fillStatus', `✓ Filled ${n} field${n !== 1 ? 's' : ''} successfully`, 'success');
        }
      });
    });
  });

  // Save settings
  document.getElementById('btnSaveSettings').addEventListener('click', () => {
    const email = document.getElementById('s_email').value.trim();
    const website = document.getElementById('s_website').value.trim();

    if (!email) {
      showStatus('settingsStatus', '⚠ Email is required', 'error');
      return;
    }

    getSettings(cur => {
      saveSettings(Object.assign({}, cur, { email, website }), () => {
        showStatus('settingsStatus', '✓ Settings saved', 'success');
      });
    });
  });

  // Auto-save settings while typing (survives tab switch + popup close)
  let settingsAutosaveTimer;
  function scheduleSettingsAutosave() {
    clearTimeout(settingsAutosaveTimer);
    settingsAutosaveTimer = setTimeout(() => {
      getSettings(base => {
        saveSettings(Object.assign({}, base, {
          email: document.getElementById('s_email').value,
          website: document.getElementById('s_website').value
        }));
      });
    }, 400);
  }
  ['s_email', 's_website'].forEach(id => {
    document.getElementById(id).addEventListener('input', scheduleSettingsAutosave);
  });

  // ── Comment Tab ─────────────────────────────────────────────────────────────

  let detectedPageContent = null;
  let lastGeneratedComment = '';

  loadCommentState(state => {
    if (!state) return;
    if (state.niche != null) document.getElementById('c_niche').value = state.niche;
    if (state.tone) document.getElementById('c_tone').value = state.tone;
    if (state.lang) document.getElementById('c_lang').value = state.lang;
    if (state.commentDraft != null) document.getElementById('commentOutput').value = state.commentDraft;
    if (state.lastGeneratedComment) lastGeneratedComment = state.lastGeneratedComment;
    if (state.cachedPageContent) {
      detectedPageContent = state.cachedPageContent;
      document.getElementById('pageTopic').textContent = state.cachedPageContent.title || 'Page content loaded';
      document.getElementById('pageTopicBox').style.display = 'block';
    }
  });

  let commentDraftTimer;
  function scheduleCommentDraftSave() {
    clearTimeout(commentDraftTimer);
    commentDraftTimer = setTimeout(() => {
      patchCommentState({ commentDraft: document.getElementById('commentOutput').value });
    }, 300);
  }
  document.getElementById('commentOutput').addEventListener('input', scheduleCommentDraftSave);

  document.getElementById('c_niche').addEventListener('input', () => {
    patchCommentState({ niche: document.getElementById('c_niche').value.trim() });
  });
  document.getElementById('c_tone').addEventListener('change', () => {
    patchCommentState({ tone: document.getElementById('c_tone').value });
  });
  document.getElementById('c_lang').addEventListener('change', () => {
    patchCommentState({ lang: document.getElementById('c_lang').value });
  });

  document.getElementById('btnReadPage').addEventListener('click', () => {
    showStatus('commentStatus', '⏳ Reading page...', 'info');
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      chrome.tabs.sendMessage(tabs[0].id, { action: 'getPageContent' }, response => {
        if (chrome.runtime.lastError || !response) {
          showStatus('commentStatus', '⚠ Could not read page — refresh and try again', 'error');
          return;
        }
        if (response.error === 'auth_required') {
          showStatus('commentStatus', '⚠ Pehle account login karein.', 'error');
          return;
        }
        if (response.error === 'subscription_inactive') {
          showStatus('commentStatus', '⚠ Trial End — open extension popup (199 PKR / month).', 'error');
          return;
        }
        detectedPageContent = response.content;
        document.getElementById('pageTopic').textContent = detectedPageContent.title || 'Page content loaded';
        document.getElementById('pageTopicBox').style.display = 'block';
        document.getElementById('commentOutput').value = '';
        lastGeneratedComment = '';
        patchCommentState({
          cachedPageContent: response.content,
          commentDraft: '',
          lastGeneratedComment: ''
        });
        showStatus('commentStatus', '✓ Page read — now generate comment', 'success');
      });
    });
  });

  let retryCount = 0;

  function toCleanText(raw) {
    return (raw || '')
      .replace(/\r\n/g, '\n')
      .replace(/\n+/g, ' ')
      .replace(/\s+/g, ' ')
      .replace(/^[\-\*\d.\)\s]+/, '')
      .trim();
  }

  function normalizeCommentReply(text) {
    const clean = toCleanText(text);
    if (!clean) return '';
    return clean.slice(0, 4000);
  }

  function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function hasNicheMention(text, niche) {
    if (!niche) return true;
    const raw = niche.trim();
    if (!raw) return true;

    const t = (text || '').toLowerCase();
    const n = raw.toLowerCase();

    // Exact phrase (case-insensitive)
    if (t.includes(n)) return true;

    // Same words with flexible space / hyphen between them
    const norm = s => s.toLowerCase().replace(/[\s\-_]+/g, ' ').trim();
    if (norm(text).includes(norm(raw))) return true;

    // Token match: 2+ chars, or 2-letter ALL-CAPS acronyms from original niche
    const rawTokens = raw.split(/[\s\-_]+/).filter(Boolean);
    const tokens = rawTokens
      .map((tok, i) => {
        const lower = tok.toLowerCase();
        if (tok.length >= 3) return lower;
        if (tok.length === 2 && /^[A-Z]{2}$/.test(tok)) return lower;
        if (tok.length >= 2 && /^[A-Z0-9]{2,}$/i.test(tok)) return lower;
        return null;
      })
      .filter(Boolean);

    if (!tokens.length) {
      return t.includes(rawTokens[0].toLowerCase());
    }

    let matched = 0;
    for (const tok of tokens) {
      const re = new RegExp(`(?:^|[^a-z0-9])${escapeRegExp(tok)}(?:$|[^a-z0-9])`, 'i');
      if (re.test(text)) matched++;
    }
    const need = Math.max(1, Math.ceil(tokens.length * 0.6));
    return matched >= need;
  }

  const GROQ_MODEL = 'llama-3.3-70b-versatile';

  function getCommentAIConfig() {
    return { model: GROQ_MODEL, providerLabel: 'Groq' };
  }

  function chatErrorMessage(data) {
    const e = data && data.error;
    if (!e) return '';
    if (typeof e === 'string') return e;
    return e.message || '';
  }

  function isChatRateLimitError(data) {
    const msg = chatErrorMessage(data).toLowerCase();
    const e = data && data.error;
    const code = String((e && typeof e === 'object' && e.code) || '');
    return /rate limit|429|too many requests/.test(msg + code);
  }

  function formatChatRateLimitMessage(providerLabel) {
    const p = providerLabel || 'API';
    if (p === 'Groq') {
      return 'Groq rate limit — try again shortly.';
    }
    return 'AI rate limit — try again shortly.';
  }

  function callChatCompletions(cfg, prompt, opts) {
    const o = opts || {};
    return new Promise((resolve) => {
      if (typeof AUTH_API_BASE === 'undefined') {
        resolve({ error: { message: 'authConfig.js missing — reload extension' } });
        return;
      }
      chrome.storage.local.get('accountAuthSession', async (d) => {
        const sess = d.accountAuthSession;
        if (!sess || !sess.token) {
          resolve({ error: { message: 'Account login required' } });
          return;
        }
        try {
          const r = await fetch(AUTH_API_BASE + '/ai_chat.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: 'Bearer ' + sess.token
            },
            body: JSON.stringify({
              model: (o.model || (cfg && cfg.model) || GROQ_MODEL),
              messages: [{ role: 'user', content: prompt }],
              max_tokens: o.max_tokens != null ? o.max_tokens : 512,
              temperature: o.temperature != null ? o.temperature : 1
            })
          });
          const raw = await r.text();
          let data = {};
          try {
            data = raw ? JSON.parse(raw) : {};
          } catch (_) {
            resolve({
              error: {
                message: 'Bad response HTTP ' + r.status + ': ' + String(raw).slice(0, 220)
              }
            });
            return;
          }
          if (!r.ok) {
            const err = data.error || { message: data.message || `HTTP ${r.status}` };
            resolve({ error: typeof err === 'string' ? { message: err } : err });
            return;
          }
          resolve(data);
        } catch (e) {
          resolve({ error: { message: (e && e.message) ? e.message : 'Network / CORS error — upload latest api/common.php' } });
        }
      });
    });
  }

  function extractChatText(data) {
    return (data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';
  }

  function getCommentLanguageInstruction(lang) {
    const m = {
      english: 'MANDATORY LANGUAGE: English.',
      urdu_roman: 'MANDATORY LANGUAGE: Roman Urdu (Urdu in English letters), natural and readable.',
      spanish: 'MANDATORY LANGUAGE: Spanish.',
      indonesian: 'MANDATORY LANGUAGE: Indonesian (Bahasa Indonesia). Write the entire comment in Indonesian only.',
      turkish: 'MANDATORY LANGUAGE: Turkish. Write the entire comment in Turkish only.',
      french: 'MANDATORY LANGUAGE: French. Write the entire comment in French only.',
      german: 'MANDATORY LANGUAGE: German. Write the entire comment in German only.',
      dutch: 'MANDATORY LANGUAGE: Dutch. Write the entire comment in Dutch only.'
    };
    return m[lang] || m.english;
  }

  const SHORT_COMMENT_MAX_CHARS = 320;

  function enforceShortCommentMaxChars(cfg, text, lang, tone) {
    if (tone !== 'short' || !text) return Promise.resolve(text);
    const s = String(text);
    if (s.length <= SHORT_COMMENT_MAX_CHARS) return Promise.resolve(s);
    const p = `The comment is too long. Rewrite it so the final text is at most ${SHORT_COMMENT_MAX_CHARS} characters total (count every character including spaces and line breaks). Do not exceed ${SHORT_COMMENT_MAX_CHARS}.

${getCommentLanguageInstruction(lang)}
Keep the same topic angle and niche wording if present. End with . or ! or ?

Return only the rewritten comment, no quotes or labels.

Comment:
${s}`;

    return callChatCompletions(cfg, p, { temperature: 0.35, max_tokens: 220 })
      .then((data) => {
        if (data.error) return s.slice(0, SHORT_COMMENT_MAX_CHARS);
        const out = normalizeCommentReply(extractChatText(data));
        if (!out) return s.slice(0, SHORT_COMMENT_MAX_CHARS);
        if (out.length <= SHORT_COMMENT_MAX_CHARS) return out;
        return out.slice(0, SHORT_COMMENT_MAX_CHARS);
      })
      .catch(() => s.slice(0, SHORT_COMMENT_MAX_CHARS));
  }

  function repairCommentWithNiche(cfg, draft, niche, lang, tone) {
    const langLine = getCommentLanguageInstruction(lang);
    const shortLine = tone === 'short'
      ? `\n5) HARD LIMIT: entire output must be ${SHORT_COMMENT_MAX_CHARS} characters or fewer (count spaces).`
      : '';
    const repairPrompt = `You are editing a blog/forum comment.

Rewrite the draft so that:
1) It still engages with the blog topic first (one concrete point from the post).
2) The niche connects through a clear, believable link to that topic (not a random add-on).
3) This exact phrase appears exactly ONCE, woven into the middle flow if possible — avoid putting it only in the final sentence: ${JSON.stringify(niche)}
4) Max 4–5 short lines; complete sentences; no SEO/marketing tone.${shortLine}

${langLine}
Do not change language; keep the whole reply in that language only.

Current draft:
${draft}`;

    const maxTok = tone === 'short' ? 220 : 380;
    return callChatCompletions(cfg, repairPrompt, { temperature: 0.5, max_tokens: maxTok });
  }

  function hasSelectedTone(text, tone) {
    const t = (text || '').toLowerCase();
    if (!t) return false;

    if (tone === 'short') {
      const raw = text || '';
      const sentenceCount = (raw.match(/[.!?]+/g) || []).length;
      return raw.length <= SHORT_COMMENT_MAX_CHARS && sentenceCount <= 3;
    }

    if (tone === 'professional') {
      // Avoid slang-heavy style in professional mode.
      return !/\b(yar|yaar|bro|bhai|lol|omg|awesome|superb)\b/i.test(t);
    }

    // friendly tone: allow default output unless it sounds too formal/robotic.
    return true;
  }

  function rewriteToTone(cfg, draft, tone, lang) {
    const toneMap = {
      friendly: 'friendly, warm, conversational',
      professional: 'professional, clear, polished',
      short: 'very concise and to-the-point'
    };
    const langMap = {
      english: 'English',
      urdu_roman: 'Roman Urdu (Urdu in English letters)',
      spanish: 'Spanish',
      indonesian: 'Indonesian (Bahasa Indonesia)',
      turkish: 'Turkish',
      french: 'French',
      german: 'German',
      dutch: 'Dutch'
    };
    const shortRules = tone === 'short'
      ? `\n- HARD LIMIT: final text must be ${SHORT_COMMENT_MAX_CHARS} characters or fewer (count every character). Do not exceed this.`
      : '';
    const rewritePrompt = `Rewrite the comment to strictly match this style:
- Tone: ${toneMap[tone] || toneMap.friendly}
- Language: ${langMap[lang] || langMap.english}

Rules:
- Keep the original meaning/topic.
- Keep niche mention count unchanged.${shortRules}
- Return only final rewritten comment text.

Comment:
${draft}`;

    const maxTok = tone === 'short' ? 200 : 320;
    return callChatCompletions(cfg, rewritePrompt, { temperature: 0.4, max_tokens: maxTok });
  }

  function generateComment(isRegenerate = false) {
    if (!detectedPageContent) {
      showStatus('commentStatus', '⚠ Read the page first', 'error');
      return;
    }
    getSettings(s => {
      const cfg = getCommentAIConfig();
      showStatus('commentStatus', '⏳ Generating comment...', 'info');
      document.getElementById('commentOutput').value = '';
      patchCommentState({ commentDraft: '' });

      const niche = document.getElementById('c_niche').value.trim();
      const tone = document.getElementById('c_tone').value;
      const lang = document.getElementById('c_lang').value;
      const variationInstruction = isRegenerate && lastGeneratedComment
        ? `Previous comment (do NOT repeat this wording or angle): ${lastGeneratedComment}
Write a distinctly different comment with a new angle while staying relevant.`
        : '';

      const nicheInstruction = niche
        ? `NICHE (exactly ONE mention in the whole reply, phrase: "${niche}"):
- Your job is to build a believable LINK between the blog post's topic and this niche — any honest angle counts: same problem, overlapping audience, a parallel example, a tool/workflow that fits, something the article reminded you of, etc. The niche must feel relevant to what the post is about, not random.
- Weave the niche into the flow where it fits (middle of the comment is fine). Do NOT default to sticking it only in the last sentence or as a tacked-on afterthought — avoid "by the way…" at the end.
- Use the exact phrase once; only small capitalization/grammar fixes allowed. Never repeat it twice.`
        : '';

      const lengthStyleBlock = tone === 'short'
        ? `LENGTH & STYLE (tone = SHORT):
- HARD CHARACTER LIMIT: the entire comment must be ${SHORT_COMMENT_MAX_CHARS} characters or fewer (count every character: letters, spaces, punctuation).
- Prefer 2–3 very short sentences; end with . ! or ?
- Sound human; no filler; no SEO tone.`
        : `LENGTH & STYLE:
- 4–5 short lines maximum total.
- Complete sentences; sound human; no cut-off endings.
- No "Great post!" / "Nice article!" filler. No SEO or marketing tone.`;

      const prompt = `You are writing a public comment on a blog or forum post.

Context from the page:
- Title: ${detectedPageContent.title}
- Main heading: ${detectedPageContent.h1 || ''}
- Content excerpt: ${detectedPageContent.body}
${variationInstruction}
${nicheInstruction}

HOW TO WRITE IT:
1) Start by reacting to the post itself — one specific idea or detail from the content (not generic praise).
2)${niche ? ` Bridge from that point to your niche: explain in one short beat WHY this post connects to "${niche}" (shared theme, useful overlap, personal experience, etc.), then work the niche phrase into that bridge naturally — not bolted on at the very end.` : ' Finish your thought naturally.'}

${lengthStyleBlock}

Return ONLY the comment text, nothing else.`;

      const toneInstructionMap = {
        friendly: 'MANDATORY TONE: friendly, warm, conversational (human and approachable).',
        professional: 'MANDATORY TONE: professional, clear, polished (no slang, no casual filler).',
        short: `MANDATORY TONE: SHORT — very concise. HARD LIMIT: the full comment must be ${SHORT_COMMENT_MAX_CHARS} characters or fewer (count every character). Never exceed ${SHORT_COMMENT_MAX_CHARS}.`
      };
      const styleInstruction = `${toneInstructionMap[tone] || toneInstructionMap.friendly}\n${getCommentLanguageInstruction(lang)}`;
      const fullPrompt = `${prompt}

STYLE OVERRIDE (STRICTLY FOLLOW):
${styleInstruction}
- If tone is "short", the entire output must be ${SHORT_COMMENT_MAX_CHARS} characters or fewer (strict). No exceptions.
- Do not ignore tone/language instructions.`;

      const finalizeShortIfNeeded = (txt) => enforceShortCommentMaxChars(cfg, txt, lang, tone);

      callChatCompletions(cfg, fullPrompt, { temperature: 1, max_tokens: tone === 'short' ? 220 : 380 })
      .then(data => {
        if (data.error) {
          const apiMsg = chatErrorMessage(data) || '';
          const userMsg = isChatRateLimitError(data) ? formatChatRateLimitMessage(cfg.providerLabel) : apiMsg;
          showStatus('commentStatus', '⚠ ' + userMsg, 'error');
          return;
        }
        let text = extractChatText(data);
        if (!text) { showStatus('commentStatus', '⚠ Empty response — try again', 'error'); return; }

        const fixed = normalizeCommentReply(text);
        const endsClean = /[.!?]$/.test(fixed);
        const nicheOk = hasNicheMention(fixed, niche);
        const toneOk = hasSelectedTone(fixed, tone);

        if (!fixed || !endsClean || !nicheOk || !toneOk) {
          if (retryCount < 2) {
            retryCount++;
            const reason = !nicheOk ? 'niche missing' : (!toneOk ? 'tone mismatch' : 'incomplete response');
            showStatus('commentStatus', `⏳ ${reason}, retrying (${retryCount}/2)...`, 'info');
            setTimeout(() => generateComment(isRegenerate), 1500);
          } else {
            retryCount = 0;
            const needsRepair = Boolean(niche && fixed && (!nicheOk || !endsClean));
            if (needsRepair) {
              showStatus('commentStatus', '⏳ Fitting niche into reply...', 'info');
              repairCommentWithNiche(cfg, fixed, niche, lang, tone)
                .then(data2 => {
                  if (data2.error) {
                    const apiMsg2 = chatErrorMessage(data2) || '';
                    const userMsg2 = isChatRateLimitError(data2) ? formatChatRateLimitMessage(cfg.providerLabel) : apiMsg2;
                    showStatus('commentStatus', '⚠ ' + userMsg2, 'error');
                    return;
                  }
                  const text2 = extractChatText(data2);
                  const fixed2 = normalizeCommentReply(text2);
                  const ok = fixed2 && /[.!?]$/.test(fixed2) && hasNicheMention(fixed2, niche);
                  if (!ok) {
                    showStatus('commentStatus', '⚠ Could not include niche naturally — try Regenerate', 'error');
                    return;
                  }
                  finalizeShortIfNeeded(fixed2).then((out2) => {
                    const final2 = normalizeCommentReply(out2);
                    lastGeneratedComment = final2;
                    document.getElementById('commentOutput').value = final2;
                    patchCommentState({
                      commentDraft: final2,
                      lastGeneratedComment: final2,
                      cachedPageContent: detectedPageContent,
                      tone,
                      lang
                    });
                    showStatus('commentStatus', '✓ Comment ready!', 'success');
                  });
                })
                .catch(() => showStatus('commentStatus', '⚠ Network error — check API key', 'error'));
              return;
            }
            if (fixed && !toneOk) {
              showStatus('commentStatus', '⏳ Adjusting tone...', 'info');
              rewriteToTone(cfg, fixed, tone, lang)
                .then(data3 => {
                  if (data3.error) {
                    const apiMsg3 = chatErrorMessage(data3) || '';
                    const userMsg3 = isChatRateLimitError(data3) ? formatChatRateLimitMessage(cfg.providerLabel) : apiMsg3;
                    showStatus('commentStatus', '⚠ ' + userMsg3, 'error');
                    return;
                  }
                  const text3 = extractChatText(data3);
                  const fixed3 = normalizeCommentReply(text3);
                  const ok3 = fixed3 && /[.!?]$/.test(fixed3) && hasNicheMention(fixed3, niche) && hasSelectedTone(fixed3, tone);
                  if (!ok3) {
                    showStatus('commentStatus', '⚠ Tone still not matching — try Regenerate', 'error');
                    return;
                  }
                  finalizeShortIfNeeded(fixed3).then((out3) => {
                    const final3 = normalizeCommentReply(out3);
                    lastGeneratedComment = final3;
                    document.getElementById('commentOutput').value = final3;
                    patchCommentState({
                      commentDraft: final3,
                      lastGeneratedComment: final3,
                      cachedPageContent: detectedPageContent,
                      tone,
                      lang
                    });
                    showStatus('commentStatus', '✓ Comment ready!', 'success');
                  });
                })
                .catch(() => showStatus('commentStatus', '⚠ Network error — check API key', 'error'));
              return;
            }
            const failMsg = niche
              ? '⚠ Could not include niche naturally — try Regenerate'
              : (!toneOk ? '⚠ Tone mismatch — try Regenerate' : '⚠ Could not get complete response — try again');
            showStatus('commentStatus', failMsg, 'error');
          }
          return;
        }

        retryCount = 0;
        finalizeShortIfNeeded(fixed).then((out) => {
          const final = normalizeCommentReply(out);
          lastGeneratedComment = final;
          document.getElementById('commentOutput').value = final;
          patchCommentState({
            commentDraft: final,
            lastGeneratedComment: final,
            cachedPageContent: detectedPageContent,
            tone,
            lang
          });
          showStatus('commentStatus', '✓ Comment ready!', 'success');
        });
      })
      .catch(() => showStatus('commentStatus', '⚠ Network error — check API key', 'error'));
    });
  }

  document.getElementById('btnGenComment').addEventListener('click', () => generateComment(false));
  document.getElementById('btnRegenComment').addEventListener('click', () => generateComment(true));

  document.getElementById('btnCopyComment').addEventListener('click', () => {
    const text = document.getElementById('commentOutput').value;
    if (!text) { showStatus('commentStatus', '⚠ No comment to copy', 'error'); return; }
    navigator.clipboard.writeText(text).then(() => {
      showStatus('commentStatus', '✓ Copied to clipboard!', 'success');
    });
  });

  // ── Queries Tab ─────────────────────────────────────────────────────────────

  const extensionSet = new Set();

  function persistQueriesState(queries = null) {
    const state = {
      term: document.getElementById('q_term').value.trim(),
      type: document.getElementById('q_type').value,
      extensions: Array.from(extensionSet),
      queries
    };
    saveQueriesState(state);
  }

  function normalizeExtension(raw) {
    const value = (raw || '').trim().toLowerCase();
    if (!value) return '';

    let cleaned = value;
    if (cleaned.startsWith('site:')) {
      cleaned = cleaned.replace(/^site:/, '');
    }
    if (!cleaned.startsWith('.')) {
      cleaned = '.' + cleaned;
    }
    cleaned = cleaned.replace(/[^a-z.]/g, '');

    if (cleaned.length < 2) return '';
    return cleaned;
  }

  function renderExtensionChips() {
    const wrap = document.getElementById('extensionChips');
    if (extensionSet.size === 0) {
      wrap.innerHTML = '';
      return;
    }

    wrap.innerHTML = Array.from(extensionSet).map(ext => `
      <span class="chip">
        ${ext}
        <button type="button" data-ext="${ext}" aria-label="Remove ${ext}">x</button>
      </span>
    `).join('');

    wrap.querySelectorAll('button[data-ext]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (isEduQueryType()) return;
        extensionSet.delete(btn.dataset.ext);
        renderExtensionChips();
        persistQueriesState();
      });
    });

    if (isEduQueryType()) {
      wrap.querySelectorAll('button[data-ext]').forEach(btn => {
        btn.disabled = true;
      });
    }
  }

  function isEduQueryType() {
    return document.getElementById('q_type').value === 'eduposts';
  }

  function updateQueriesExtensionUi() {
    const edu = isEduQueryType();
    const input = document.getElementById('q_extension');
    const btn = document.getElementById('btnAddExtension');
    input.disabled = edu;
    btn.disabled = edu;
    const hint = input.closest('.fg')?.querySelector('.hint');
    if (hint) {
      hint.textContent = edu
        ? 'Edu queries always use site:.edu — custom domain extension is not available for this type.'
        : 'Example: .com, .org, .pk';
    }
    renderExtensionChips();
  }

  function renderQueriesResults(queries) {
    const results = document.getElementById('queryResults');
    results.innerHTML = queries.map((q, idx) => `
      <div class="query-box">
        <div style="font-size:11px;color:#666;margin-bottom:6px;font-weight:600;">Query ${idx + 1}</div>
        <div>${q}</div>
        <div style="display:flex;gap:8px;margin-top:8px;">
          <button class="btn btn-light" data-query="${encodeURIComponent(q)}">Copy</button>
          <button class="btn btn-find-placements" data-google="${encodeURIComponent(q)}">Find Placements</button>
        </div>
      </div>
    `).join('');

    results.querySelectorAll('button[data-query]').forEach(btn => {
      btn.addEventListener('click', () => {
        const query = decodeURIComponent(btn.dataset.query);
        navigator.clipboard.writeText(query).then(() => {
          showStatus('queriesStatus', '✓ Query copied', 'success');
        });
      });
    });

    results.querySelectorAll('button[data-google]').forEach(btn => {
      btn.addEventListener('click', () => {
        const query = decodeURIComponent(btn.dataset.google);
        const url = 'https://www.google.com/search?q=' + encodeURIComponent(query);
        chrome.tabs.create({ url });
      });
    });
  }

  function buildOptimizedQueries(term, type, domainExtension) {
    const t = `"${term}"`;
    const ext = domainExtension ? ` site:${domainExtension}` : '';

    // Map existing UI values to requested type keys.
    const normalizedType = (
      type === 'forum-sites' ? 'forum-sites' :
      type === 'forum' ? 'forum-sites' :
      type === 'forum-posts' ? 'forum-posts' :
      type === 'forumposts' ? 'forum-posts' :
      type === 'edu-posts' ? 'edu-posts' :
      type === 'eduposts' ? 'edu-posts' :
      type === 'comment' ? 'obl-comments' :
      type === 'alreadycommented' ? 'already-commented' :
      type === 'guestpost' ? 'guest-post' :
      ''
    );

    if (normalizedType === 'forum-sites') {
      return [
        `inurl:forum ${t} "register" OR "sign up" -inurl:".php?reply"${ext}`,
        `${t} "post reply" OR "new thread" forum -site:facebook.com${ext}`
      ];
    }

    if (normalizedType === 'forum-posts') {
      return [
        `${t} inurl:forum "reply" OR "post reply" -inurl:register -inurl:login${ext}`,
        `${t} "powered by phpBB" inurl:viewtopic${ext}`,
        `${t} "powered by vBulletin" inurl:showthread${ext}`
      ];
    }

    if (normalizedType === 'edu-posts') {
      return [
        `${t} site:.edu "post a comment" -"comments closed" -"you must be logged in" -filetype:pdf`,
        `${t} site:.edu "Your email address will not be published" -"comments are closed" -filetype:pdf`,
        `${t} site:.edu ("Leave a Reply" OR "Add a comment" OR "Join the discussion") -"you must be logged in" -filetype:pdf`
      ];
    }

    if (normalizedType === 'obl-comments') {
      return [
        `${t} "Be the first to comment" "Your email address will not be published" -filetype:pdf${ext}`,
        `${t} "No comments yet" ("Leave a Reply" OR "Leave a comment") -"comments closed" -filetype:pdf${ext}`,
        `${t} intitle:${t} ("0 comments" OR "No Comments") "Your email address will not be published" -filetype:pdf${ext}`
      ];
    }

    if (normalizedType === 'already-commented') {
      return [
        `${t} ("2 comments" OR "3 comments" OR "4 comments" OR "5 comments" OR "6 comments" OR "7 comments" OR "8 comments" OR "9 comments" OR "10 comments" OR "11 comments" OR "12 comments" OR "13 comments" OR "14 comments" OR "15 comments") "Your email address will not be published" (inurl:blog OR inurl:post OR inurl:article) -filetype:pdf${ext}`,
        `${t} intext:"says:" "Leave a Reply" -"comments are closed" -"you must be logged in" -filetype:pdf${ext}`,
        `${t} "CommentLuv badge" ("1 comment" OR "2 comments" OR "3 comments") -filetype:pdf${ext}`
      ];
    }

    if (normalizedType === 'guest-post') {
      return [
        `${t} intitle:"write for us" OR intitle:"write for me" inurl:write-for-us -filetype:pdf${ext}`,
        `${t} (intitle:"guest post" OR intitle:"guest article" OR intitle:"submit a post" OR intitle:"contribute") ("guidelines" OR "submission") -filetype:pdf${ext}`
      ];
    }

    return [];
  }

  document.getElementById('btnAddExtension').addEventListener('click', () => {
    if (isEduQueryType()) {
      showStatus('queriesStatus', '⚠ Custom domain extension is not used for Edu posts.', 'error');
      return;
    }
    const input = document.getElementById('q_extension');
    const ext = normalizeExtension(input.value);

    if (!ext) {
      showStatus('queriesStatus', '⚠ Enter valid extension like .com or .co.uk', 'error');
      return;
    }

    extensionSet.add(ext);
    input.value = '';
    renderExtensionChips();
    persistQueriesState();
    showStatus('queriesStatus', `✓ Added ${ext}`, 'success');
  });

  document.getElementById('q_extension').addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      document.getElementById('btnAddExtension').click();
    }
  });

  document.getElementById('btnGenerateQueries').addEventListener('click', () => {
    const term = document.getElementById('q_term').value.trim();
    const type = document.getElementById('q_type').value;

    if (!term) {
      showStatus('queriesStatus', '⚠ Please enter a term first', 'error');
      return;
    }

    // Spec: optional single domainExtension, appended as `site:{domainExtension}`.
    const domainExtension = type === 'eduposts' ? '' : (extensionSet.size ? Array.from(extensionSet)[0] : '');
    const queries = buildOptimizedQueries(term, type, domainExtension);
    if (!queries.length) {
      showStatus('queriesStatus', '⚠ Could not build queries for selected type', 'error');
      return;
    }

    renderQueriesResults(queries);
    persistQueriesState(queries);

    showStatus('queriesStatus', `✓ ${queries.length} optimized queries ready`, 'success');
  });

  document.getElementById('q_term').addEventListener('input', () => persistQueriesState());
  document.getElementById('q_type').addEventListener('change', () => {
    updateQueriesExtensionUi();
    persistQueriesState();
  });

  loadQueriesState(state => {
    if (!state) return;

    if (state.term) {
      document.getElementById('q_term').value = state.term;
    }
    if (state.type) {
      let normalizedType = state.type === 'edu' ? 'eduposts' : state.type;
      if (normalizedType === 'profile') normalizedType = 'forum';
      document.getElementById('q_type').value = normalizedType;
    }

    extensionSet.clear();
    (state.extensions || []).forEach(ext => {
      const normalized = normalizeExtension(ext);
      if (normalized) extensionSet.add(normalized);
    });

    if (Array.isArray(state.queries) && state.queries.length) {
      renderQueriesResults(state.queries);
    }

    updateQueriesExtensionUi();
  });

  updateQueriesExtensionUi();

  chrome.storage.local.get('accountAuthSession', (d) => {
    const el = document.getElementById('accountSignedInLine');
    if (el && d.accountAuthSession && d.accountAuthSession.email) {
      const plan = d.accountAuthSession.plan || 'free';
      el.textContent = 'Signed in as: ' + d.accountAuthSession.email + ' (' + plan + ')';
    }
  });
  document.getElementById('btnAccountSignOut').addEventListener('click', () => {
    chrome.storage.local.remove('accountAuthSession', () => location.reload());
  });

}

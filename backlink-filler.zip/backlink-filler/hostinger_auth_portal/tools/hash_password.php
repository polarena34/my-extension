<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "CLI only.\n");
    exit(1);
}
$pwd = $argv[1] ?? '';
if ($pwd === '') {
    fwrite(STDERR, "Usage: php hash_password.php \"your password\"\n");
    exit(1);
}
echo password_hash($pwd, PASSWORD_DEFAULT), "\n";

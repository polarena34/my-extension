window.AUTH_API_BASE = window.location.origin + "/api";
// Shown after website login (override anytime without editing account-home.js)
window.BF_LOGIN_SUCCESS_MSG =
  "Done — open the extension and log in there with the same details.";

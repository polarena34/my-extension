<?php
declare(strict_types=1);
require __DIR__ . '/api/common.php';

$sql = "CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  api_token VARCHAR(255) DEFAULT NULL,
  plan VARCHAR(20) NOT NULL DEFAULT 'free',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  subscription_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

$ok = db()->query($sql);
if (!$ok) {
    outJson(['error' => 'Table create failed: ' . db()->error], 500);
}

$conn = db();
$colRes = $conn->query("SHOW COLUMNS FROM users LIKE 'full_name'");
if (!$colRes) {
    outJson(['error' => 'Could not inspect users table: ' . $conn->error], 500);
}
if ($colRes->num_rows === 0) {
    $alterOk = $conn->query("ALTER TABLE users ADD COLUMN full_name VARCHAR(120) NOT NULL DEFAULT '' AFTER id");
    if (!$alterOk) {
        outJson(['error' => 'Could not add full_name column: ' . $conn->error], 500);
    }
}

$subRes = $conn->query("SHOW COLUMNS FROM users LIKE 'subscription_active'");
if ($subRes && $subRes->num_rows === 0) {
    $alterSub = $conn->query("ALTER TABLE users ADD COLUMN subscription_active TINYINT(1) NOT NULL DEFAULT 1 AFTER is_active");
    if (!$alterSub) {
        outJson(['error' => 'Could not add subscription_active column: ' . $conn->error], 500);
    }
}

outJson(['ok' => true, 'message' => 'users table ready. Delete install.php now.']);

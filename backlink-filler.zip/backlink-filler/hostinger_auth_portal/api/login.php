<?php
declare(strict_types=1);
require __DIR__ . '/common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    outJson(['error' => 'Method not allowed'], 405);
}

$d = readJsonBody();
$email = strtolower(trim((string)($d['email'] ?? '')));
$password = (string)($d['password'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
    outJson(['error' => 'Email and password required'], 422);
}

$conn = db();
$q = $conn->prepare('SELECT id, full_name, password_hash, plan, is_active, subscription_active FROM users WHERE email = ? LIMIT 1');
$q->bind_param('s', $email);
$q->execute();
$res = $q->get_result();
$user = $res ? $res->fetch_assoc() : null;
if (!$user) {
    outJson(['error' => 'Invalid credentials'], 401);
}
if ((int)$user['is_active'] !== 1) {
    outJson(['error' => 'Account suspended'], 403);
}
if (!password_verify($password, (string)$user['password_hash'])) {
    outJson(['error' => 'Invalid credentials'], 401);
}

$token = makeToken($email, $CFG['TOKEN_SIGNING_SECRET'] ?? 'fallback');
$upd = $conn->prepare('UPDATE users SET api_token = ? WHERE id = ?');
$uid = (int)$user['id'];
$upd->bind_param('si', $token, $uid);
$upd->execute();

outJson([
    'ok' => true,
    'token' => $token,
    'full_name' => $user['full_name'],
    'email' => $email,
    'plan' => $user['plan'],
    'subscription_active' => (int)$user['subscription_active'] === 1 ? 1 : 0
]);

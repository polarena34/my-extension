<?php
/**
 * Copy to admin_config.php (same folder) and set your hash.
 * NEVER commit admin_config.php with real secrets.
 *
 * Generate hash on server or locally:
 *   php tools/hash_password.php "YourStrongPassword"
 */
return [
    'ADMIN_EMAIL' => 'muhammadabdull.460@gmail.com',
    /** bcrypt hash from tools/hash_password.php */
    'ADMIN_PASSWORD_HASH' => '$2y$10$15nei1A2u1JVOdkKA.L.8uuDaWTNuaN5GYjbvyfSkLpWFnqQhEihu',
];

<?php
return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'YOUR_DB_NAME',
    'DB_USER' => 'YOUR_DB_USER',
    'DB_PASS' => 'YOUR_DB_PASSWORD',

    'APP_URL' => 'https://your-domain.com',
    'ALLOWED_EXTENSION_ORIGIN' => 'chrome-extension://YOUR_EXTENSION_ID',
    'TOKEN_SIGNING_SECRET' => 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET_64_PLUS_CHARS',

    /** Groq secret key (gsk_...) — never commit real value to git */
    'GROQ_API_KEY' => '',
];

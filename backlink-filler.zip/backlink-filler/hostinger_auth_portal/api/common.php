<?php
declare(strict_types=1);

$configPath = __DIR__ . '/config.php';
if (!file_exists($configPath)) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Missing api/config.php']);
    exit;
}
$CFG = require $configPath;

header('Content-Type: application/json');

$origin = trim((string)($_SERVER['HTTP_ORIGIN'] ?? ''));
if ($origin === '' && function_exists('getallheaders')) {
    foreach (getallheaders() as $k => $v) {
        if (strcasecmp((string) $k, 'Origin') === 0 && $v !== null && $v !== '') {
            $origin = trim((string) $v);
            break;
        }
    }
}

$appUrl = rtrim((string) ($CFG['APP_URL'] ?? ''), '/');
$extOrigin = (string) ($CFG['ALLOWED_EXTENSION_ORIGIN'] ?? '');

$allowOrigin = '';
if ($origin !== '' && ($origin === $extOrigin || rtrim($origin, '/') === $appUrl)) {
    $allowOrigin = $origin;
} elseif (
    ($extOrigin !== '')
    && ($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS'
    && $origin === ''
) {
    // Some hosts omit Origin on preflight; extension still needs a valid ACAO for POST+Authorization.
    $allowOrigin = $extOrigin;
}

if ($allowOrigin !== '') {
    header('Access-Control-Allow-Origin: ' . $allowOrigin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function outJson(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function readJsonBody(): array {
    $raw = file_get_contents('php://input') ?: '';
    $d = json_decode($raw, true);
    if (!is_array($d)) {
        return [];
    }
    return $d;
}

function makeToken(string $email, string $secret): string {
    $nonce = bin2hex(random_bytes(16));
    $sig = hash_hmac('sha256', $email . '|' . $nonce . '|' . time(), $secret);
    return $nonce . '.' . $sig;
}

function db(mysqli $conn = null): mysqli {
    static $instance = null;
    global $CFG;
    if ($instance instanceof mysqli) {
        return $instance;
    }
    $instance = @new mysqli(
        $CFG['DB_HOST'] ?? '',
        $CFG['DB_USER'] ?? '',
        $CFG['DB_PASS'] ?? '',
        $CFG['DB_NAME'] ?? ''
    );
    if ($instance->connect_errno) {
        outJson(['error' => 'DB connect failed'], 500);
    }
    $instance->set_charset('utf8mb4');
    return $instance;
}

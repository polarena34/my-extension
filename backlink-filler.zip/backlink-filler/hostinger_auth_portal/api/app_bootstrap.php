<?php
declare(strict_types=1);

/**
 * Shared bootstrap for HTML pages (admin) — no JSON/CORS headers.
 */
$configPath = __DIR__ . '/config.php';
if (!file_exists($configPath)) {
    http_response_code(500);
    exit('Missing api/config.php');
}
$CFG = require $configPath;

function app_db(): mysqli
{
    global $CFG;
    static $instance = null;
    if ($instance instanceof mysqli) {
        return $instance;
    }
    $instance = @new mysqli(
        $CFG['DB_HOST'] ?? '',
        $CFG['DB_USER'] ?? '',
        $CFG['DB_PASS'] ?? '',
        $CFG['DB_NAME'] ?? ''
    );
    if ($instance->connect_errno) {
        http_response_code(500);
        exit('DB connect failed');
    }
    $instance->set_charset('utf8mb4');
    return $instance;
}

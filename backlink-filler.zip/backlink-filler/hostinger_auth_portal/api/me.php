<?php
declare(strict_types=1);
require __DIR__ . '/common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    outJson(['error' => 'Method not allowed'], 405);
}

$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (!preg_match('/Bearer\s+(.+)/i', $auth, $m)) {
    outJson(['error' => 'Missing bearer token'], 401);
}
$token = trim($m[1]);

$conn = db();
$q = $conn->prepare('SELECT id, full_name, email, plan, is_active, subscription_active FROM users WHERE api_token = ? LIMIT 1');
$q->bind_param('s', $token);
$q->execute();
$res = $q->get_result();
$user = $res ? $res->fetch_assoc() : null;
if (!$user) {
    outJson(['error' => 'Invalid token'], 401);
}
if ((int)$user['is_active'] !== 1) {
    outJson(['error' => 'Account suspended'], 403);
}

outJson([
    'ok' => true,
    'user' => [
        'id' => (int)$user['id'],
        'full_name' => $user['full_name'],
        'email' => $user['email'],
        'plan' => $user['plan'],
        'subscription_active' => (int)$user['subscription_active'] === 1 ? 1 : 0
    ]
]);

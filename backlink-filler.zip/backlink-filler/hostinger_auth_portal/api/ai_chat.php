<?php
declare(strict_types=1);
require __DIR__ . '/common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    outJson(['error' => ['message' => 'Method not allowed']], 405);
}

$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (!preg_match('/Bearer\s+(.+)/i', $auth, $m)) {
    outJson(['error' => ['message' => 'Missing bearer token']], 401);
}
$token = trim($m[1]);

$conn = db();
$q = $conn->prepare('SELECT id, subscription_active, is_active FROM users WHERE api_token = ? LIMIT 1');
$q->bind_param('s', $token);
$q->execute();
$res = $q->get_result();
$user = $res ? $res->fetch_assoc() : null;
if (!$user) {
    outJson(['error' => ['message' => 'Invalid token']], 401);
}
if ((int)$user['is_active'] !== 1) {
    outJson(['error' => ['message' => 'Account suspended']], 403);
}
if ((int)$user['subscription_active'] !== 1) {
    outJson(['error' => ['message' => 'Subscription inactive']], 403);
}

$groqKey = trim((string)($CFG['GROQ_API_KEY'] ?? ''));
if ($groqKey === '') {
    outJson(['error' => ['message' => 'Server AI not configured (GROQ_API_KEY)']], 503);
}

$body = readJsonBody();
$messages = $body['messages'] ?? null;
if (!is_array($messages) || count($messages) < 1) {
    outJson(['error' => ['message' => 'Invalid messages']], 422);
}

$allowedModels = [
    'llama-3.3-70b-versatile',
    'llama-3.1-8b-instant',
    'mixtral-8x7b-32768',
];
$model = (string)($body['model'] ?? 'llama-3.3-70b-versatile');
if (!in_array($model, $allowedModels, true)) {
    $model = 'llama-3.3-70b-versatile';
}

$totalChars = 0;
$sanitized = [];
foreach ($messages as $row) {
    if (!is_array($row)) {
        continue;
    }
    $role = (string)($row['role'] ?? 'user');
    if (!in_array($role, ['user', 'system', 'assistant'], true)) {
        $role = 'user';
    }
    $content = (string)($row['content'] ?? '');
    if (strlen($content) > 24000) {
        $content = substr($content, 0, 24000);
    }
    $totalChars += strlen($content);
    $sanitized[] = ['role' => $role, 'content' => $content];
}
if (count($sanitized) < 1) {
    outJson(['error' => ['message' => 'Invalid messages']], 422);
}
if ($totalChars > 100000) {
    outJson(['error' => ['message' => 'Payload too large']], 413);
}

$maxTokens = isset($body['max_tokens']) ? (int)$body['max_tokens'] : 512;
$maxTokens = max(1, min(4096, $maxTokens));
$temperature = isset($body['temperature']) ? (float)$body['temperature'] : 1.0;
$temperature = max(0.0, min(2.0, $temperature));

$payload = json_encode([
    'model' => $model,
    'messages' => $sanitized,
    'max_tokens' => $maxTokens,
    'temperature' => $temperature,
], JSON_UNESCAPED_UNICODE);

if (!function_exists('curl_init')) {
    outJson(['error' => ['message' => 'cURL not available on server']], 500);
}

$ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $groqKey,
    ],
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_TIMEOUT => 120,
]);
$response = curl_exec($ch);
$errno = curl_errno($ch);
$code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

if ($response === false || $errno !== 0) {
    outJson(['error' => ['message' => 'Upstream request failed']], 502);
}

if ($code < 100 || $code >= 600) {
    $code = 500;
}
http_response_code($code);
header('Content-Type: application/json');
echo $response;
exit;

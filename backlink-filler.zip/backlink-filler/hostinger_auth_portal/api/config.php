<?php
return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'u374947030_backlinks_ext',
    'DB_USER' => 'u374947030_abdullah_ilyas',
    'DB_PASS' => 'g7I#|FXP!hQg7I#|FXP!hQ',

    'APP_URL' => 'https://grey-cormorant-148451.hostingersite.com',

    'ALLOWED_EXTENSION_ORIGIN' => 'chrome-extension://ljppegfihngbmmhaahnlhkmegfimbdbc',

    'TOKEN_SIGNING_SECRET' => 'a8f3d1c9e7b4a2f6d0c5b9e1a3f7d2c8b6e4a9d1f3c7b5e2a8d6f0c4b1e9a7d3',

    /** Groq API key (server-side only). Used for comment + security-question AI. */
    'GROQ_API_KEY' => ''
];
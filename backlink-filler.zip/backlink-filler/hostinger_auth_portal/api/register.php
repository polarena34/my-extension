<?php
declare(strict_types=1);
require __DIR__ . '/common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    outJson(['error' => 'Method not allowed'], 405);
}

$d = readJsonBody();
$fullName = trim((string)($d['full_name'] ?? ''));
$email = strtolower(trim((string)($d['email'] ?? '')));
$password = (string)($d['password'] ?? '');

if (mb_strlen($fullName) < 2 || mb_strlen($fullName) > 120) {
    outJson(['error' => 'Valid full name required (2-120 chars)'], 422);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    outJson(['error' => 'Valid email required'], 422);
}
if (strlen($password) < 6) {
    outJson(['error' => 'Password must be at least 6 characters'], 422);
}

$conn = db();
$check = $conn->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
$check->bind_param('s', $email);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) {
    outJson(['error' => 'Email already registered'], 409);
}
$check->close();

$hash = password_hash($password, PASSWORD_DEFAULT);
$token = makeToken($email, $CFG['TOKEN_SIGNING_SECRET'] ?? 'fallback');

$sub = 1;
$ins = $conn->prepare('INSERT INTO users (full_name, email, password_hash, api_token, subscription_active) VALUES (?, ?, ?, ?, ?)');
$ins->bind_param('ssssi', $fullName, $email, $hash, $token, $sub);
$ok = $ins->execute();
if (!$ok) {
    outJson(['error' => 'Register failed'], 500);
}

outJson([
    'ok' => true,
    'full_name' => $fullName,
    'email' => $email,
    'plan' => 'free'
], 201);

Hostinger Auth Portal (MVP)

This folder contains a simple account system for your extension:
- User signup
- User login
- Token-based auth check (`/api/me.php`)
- Plan field (`free` by default, premium later)
- Full name capture on signup

Deploy path target:
- **Isi website ka document root** (Hostinger mein har site ka folder alag ho sakta hai)

### Hostinger: "This Page Does Not Exist" lekin File Manager mein file dikhe

Aksar files **galat** `public_html` mein hoti hain (poori hosting account ka root), jab ke
`grey-cormorant-148451.hostingersite.com` ka root kuch aisa hota hai:

- `domains/grey-cormorant-148451.hostingersite.com/public_html/`

**Fix:** hPanel → **Websites** → **Manage** (sirf is temporary domain wali site) → **File Manager** — jo folder khule, wahi **asli root** hai. `install.php`, `index.html`, `api/` sab **wahan** copy karo.

Test: isi root me `health.php` upload karke kholo:
`https://grey-cormorant-148451.hostingersite.com/health.php`  
Agar yeh bhi 404 de to 100% galat folder / galat site.

Quick deploy:
1) Upload all files from this folder into `public_html`.
2) Copy `api/config.sample.php` to `api/config.php`.
3) Edit `api/config.php` with your Hostinger MySQL details and secrets.
4) Open: `https://your-domain.com/install.php` once to create table.
5) Open: `https://your-domain.com/` and test register/login.
6) Payment page: `https://your-domain.com/payment/` (folder `payment/` with `index.html`).
7) Delete `install.php` after successful setup.

If you already installed before:
- Upload latest files, then run `install.php` once again.
- It will add missing `full_name` column automatically.

Required edits in `api/config.php`:
- DB host, db name, user, pass
- `APP_URL`
- `ALLOWED_EXTENSION_ORIGIN` (chrome-extension://YOUR_EXTENSION_ID)
- `TOKEN_SIGNING_SECRET` (long random string)
- **`GROQ_API_KEY`** — your Groq API key (`gsk_...`). Used server-side for comment + security-question AI (extension users do not enter keys).

Important:
- This is an MVP starter. For production, add rate limiting, email verification,
  password reset, and stricter security headers.

## Admin panel (separate URL)

- URL: `https://your-domain.com/admin/` (login) and `https://your-domain.com/admin/dashboard.php`
- On the server, copy `api/admin_config.sample.php` to **`api/admin_config.php`** (this file is gitignored).
- Set `ADMIN_EMAIL` and `ADMIN_PASSWORD_HASH` (bcrypt). Generate hash:

```bash
php tools/hash_password.php "YourAdminPasswordHere"
```

- Paste the printed hash into `ADMIN_PASSWORD_HASH` in `api/admin_config.php`.
- **Never** commit `admin_config.php` or share admin passwords in chat/repos.

## Subscription ON/OFF (per user)

- DB column: `users.subscription_active` (1 = extension works, 0 = blocked).
- After uploading new code, open **`install.php` once** so the column is added to existing databases.
- Admin → Users table: **Subscription OFF** stops that user’s extension (trial end screen). **Subscription ON** restores access.

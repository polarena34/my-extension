<?php
declare(strict_types=1);

require __DIR__ . '/includes/admin_session.php';
require dirname(__DIR__) . '/api/app_bootstrap.php';

admin_require_login();

$csrf = admin_csrf_token();

$conn = app_db();
$res = $conn->query(
    'SELECT id, full_name, email, plan, is_active, subscription_active, created_at FROM users ORDER BY id DESC LIMIT 500'
);
$rows = [];
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $rows[] = $row;
    }
}

/** 3-day trial from created_at: ceil days while ≥24h left, then hours (then minutes). */
function admin_format_trial_left(int $secondsLeft): string
{
    if ($secondsLeft <= 0) {
        return 'Trial ended';
    }
    if ($secondsLeft >= 86400) {
        $days = (int)ceil($secondsLeft / 86400);
        return $days . ' day' . ($days === 1 ? '' : 's') . ' left';
    }
    if ($secondsLeft >= 3600) {
        $hours = (int)floor($secondsLeft / 3600);
        return $hours . ' hour' . ($hours === 1 ? '' : 's') . ' left';
    }
    $mins = max(1, (int)ceil($secondsLeft / 60));

    return $mins . ' min left';
}

function admin_trial_cell(string $createdAt): array
{
    $ts = strtotime($createdAt);
    if ($ts === false) {
        return ['end' => 0, 'label' => '—', 'class' => 'trial-na'];
    }
    $end = $ts + 3 * 86400;
    $left = $end - time();
    $label = admin_format_trial_left($left);
    $class = $left > 0 ? 'trial-on' : 'trial-ended';

    return ['end' => $end, 'label' => $label, 'class' => $class];
}

$flash = '';
$flashErr = false;
if (isset($_GET['err'])) {
    $flashErr = true;
    $flash = ($_GET['err'] === 'csrf') ? 'Security check failed. Try again.' : 'Invalid request.';
} elseif (($_GET['saved'] ?? '') === 'sub') {
    $flash = 'Subscription updated.';
} elseif (($_GET['saved'] ?? '') === 'account') {
    $flash = 'Account suspend / unsuspend updated.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Users — Admin</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: system-ui, sans-serif; background: #f8fafc; color: #0f172a; margin: 0; padding: 24px; }
    header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 12px; }
    h1 { margin: 0; font-size: 1.35rem; }
    a.btn { display: inline-block; padding: 8px 14px; background: #e2e8f0; color: #0f172a; text-decoration: none; border-radius: 8px; font-size: 0.9rem; font-weight: 600; }
    a.btn:hover { background: #cbd5e1; }
    .meta { color: #64748b; font-size: 0.85rem; }
    .flash { margin-bottom: 16px; padding: 10px 14px; border-radius: 8px; background: #ecfdf5; border: 1px solid #bbf7d0; color: #166534; font-size: 0.9rem; }
    .flash.err { background: #fef2f2; border-color: #fecaca; color: #991b1b; }
    table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,.08); }
    th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #e2e8f0; font-size: 0.875rem; }
    th { background: #1e293b; color: #f8fafc; font-weight: 600; }
    tr:last-child td { border-bottom: none; }
    tr:hover td { background: #f1f5f9; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 0.75rem; font-weight: 600; }
    .badge-free { background: #e0f2fe; color: #0369a1; }
    .badge-premium { background: #fef3c7; color: #b45309; }
    .badge-off { background: #fee2e2; color: #b91c1c; }
    .badge-on { background: #dcfce7; color: #15803d; }
    .empty { padding: 40px; text-align: center; color: #64748b; background: #fff; border-radius: 10px; }
    .btn-sub { padding: 6px 12px; border-radius: 6px; border: 1px solid #cbd5e1; font-size: 0.8rem; font-weight: 600; cursor: pointer; background: #fff; }
    .btn-sub.on { border-color: #16a34a; color: #15803d; }
    .btn-sub.off { border-color: #dc2626; color: #b91c1c; }
    .btn-sub:hover { opacity: 0.9; }
    form.inline { display: inline; margin: 0; }
    .trial-countdown { font-weight: 600; white-space: nowrap; }
    .trial-on { color: #b45309; }
    .trial-ended, .trial-na { color: #64748b; font-weight: 500; }
  </style>
</head>
<body>
  <header>
    <div>
      <h1>Registered users</h1>
      <p class="meta">Showing up to 500 users (newest first). <strong>Trial (3 days)</strong> counts down from join time (days, then hours in the last 24h). <strong>Subscription OFF</strong> = billing / plan gate. <strong>Suspended</strong> = spam or abuse; user cannot log in or use the API until unsuspended.</p>
    </div>
    <a class="btn" href="logout.php">Log out</a>
  </header>

  <?php if ($flash !== ''): ?>
    <div class="flash <?= $flashErr ? 'err' : '' ?>"><?= htmlspecialchars($flash, ENT_QUOTES, 'UTF-8') ?></div>
  <?php endif; ?>

  <?php if (count($rows) === 0): ?>
    <div class="empty">No users yet.</div>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Plan</th>
          <th>Account</th>
          <th>Subscription</th>
          <th>Billing</th>
          <th>Suspend</th>
          <th>Joined</th>
          <th>Trial (3 days)</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $u): ?>
          <tr>
            <td><?= (int)$u['id'] ?></td>
            <td><?= htmlspecialchars((string)$u['full_name'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars((string)$u['email'], ENT_QUOTES, 'UTF-8') ?></td>
            <td>
              <?php $pl = strtolower((string)$u['plan']); ?>
              <span class="badge <?= $pl === 'premium' ? 'badge-premium' : 'badge-free' ?>"><?= htmlspecialchars((string)$u['plan'], ENT_QUOTES, 'UTF-8') ?></span>
            </td>
            <td>
              <?php if ((int)$u['is_active'] === 1): ?>
                <span class="badge badge-on">Active</span>
              <?php else: ?>
                <span class="badge badge-off">Suspended</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ((int)$u['subscription_active'] === 1): ?>
                <span class="badge badge-on">ON</span>
              <?php else: ?>
                <span class="badge badge-off">OFF</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ((int)$u['subscription_active'] === 1): ?>
                <form class="inline" method="post" action="toggle_subscription.php" onsubmit="return confirm('Turn subscription OFF for this user? Extension will stop.');">
                  <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>" />
                  <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>" />
                  <input type="hidden" name="subscription_active" value="0" />
                  <button type="submit" class="btn-sub off">Subscription OFF</button>
                </form>
              <?php else: ?>
                <form class="inline" method="post" action="toggle_subscription.php">
                  <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>" />
                  <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>" />
                  <input type="hidden" name="subscription_active" value="1" />
                  <button type="submit" class="btn-sub on">Subscription ON</button>
                </form>
              <?php endif; ?>
            </td>
            <td>
              <?php if ((int)$u['is_active'] === 1): ?>
                <form class="inline" method="post" action="toggle_account_active.php" onsubmit="return confirm('Suspend this user? They cannot log in or use the API until you unsuspend.');">
                  <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>" />
                  <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>" />
                  <input type="hidden" name="is_active" value="0" />
                  <button type="submit" class="btn-sub off">Suspend</button>
                </form>
              <?php else: ?>
                <form class="inline" method="post" action="toggle_account_active.php" onsubmit="return confirm('Unsuspend this user? They can log in again.');">
                  <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>" />
                  <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>" />
                  <input type="hidden" name="is_active" value="1" />
                  <button type="submit" class="btn-sub on">Unsuspend</button>
                </form>
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars((string)$u['created_at'], ENT_QUOTES, 'UTF-8') ?></td>
            <?php $trial = admin_trial_cell((string)$u['created_at']); ?>
            <td>
              <?php if ($trial['end'] > 0): ?>
                <span class="trial-countdown <?= htmlspecialchars($trial['class'], ENT_QUOTES, 'UTF-8') ?>" data-trial-end="<?= (int)$trial['end'] ?>"><?= htmlspecialchars($trial['label'], ENT_QUOTES, 'UTF-8') ?></span>
              <?php else: ?>
                <span class="trial-countdown trial-na"><?= htmlspecialchars($trial['label'], ENT_QUOTES, 'UTF-8') ?></span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
  <script>
(function () {
  function formatTrialLeft(sec) {
    if (sec <= 0) return { text: 'Trial ended', cls: 'trial-ended' };
    if (sec >= 86400) {
      var d = Math.ceil(sec / 86400);
      return { text: d + ' day' + (d === 1 ? '' : 's') + ' left', cls: 'trial-on' };
    }
    if (sec >= 3600) {
      var h = Math.floor(sec / 3600);
      return { text: h + ' hour' + (h === 1 ? '' : 's') + ' left', cls: 'trial-on' };
    }
    var m = Math.max(1, Math.ceil(sec / 60));
    return { text: m + ' min left', cls: 'trial-on' };
  }
  function tick() {
    var now = Math.floor(Date.now() / 1000);
    document.querySelectorAll('.trial-countdown[data-trial-end]').forEach(function (el) {
      var end = parseInt(el.getAttribute('data-trial-end'), 10);
      if (!end) return;
      var o = formatTrialLeft(end - now);
      el.textContent = o.text;
      el.className = 'trial-countdown ' + o.cls;
    });
  }
  tick();
  setInterval(tick, 30000);
})();
  </script>
</body>
</html>

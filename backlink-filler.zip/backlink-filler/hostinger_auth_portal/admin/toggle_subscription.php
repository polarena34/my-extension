<?php
declare(strict_types=1);

require __DIR__ . '/includes/admin_session.php';
require dirname(__DIR__) . '/api/app_bootstrap.php';

admin_require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}

$csrf = (string)($_POST['csrf'] ?? '');
if (!admin_csrf_verify($csrf)) {
    header('Location: dashboard.php?err=csrf');
    exit;
}

$uid = (int)($_POST['user_id'] ?? 0);
$active = (int)($_POST['subscription_active'] ?? -1);
if ($uid < 1 || ($active !== 0 && $active !== 1)) {
    header('Location: dashboard.php?err=bad');
    exit;
}

$conn = app_db();
$st = $conn->prepare('UPDATE users SET subscription_active = ? WHERE id = ? LIMIT 1');
$st->bind_param('ii', $active, $uid);
$st->execute();

header('Location: dashboard.php?saved=sub');
exit;

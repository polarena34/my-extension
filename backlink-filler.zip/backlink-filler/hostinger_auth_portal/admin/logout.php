<?php
declare(strict_types=1);

require __DIR__ . '/includes/admin_session.php';

admin_logout();
header('Location: index.php');
exit;

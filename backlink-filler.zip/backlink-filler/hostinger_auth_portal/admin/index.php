<?php
declare(strict_types=1);

require __DIR__ . '/includes/admin_session.php';

if (admin_is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = (string)($_POST['email'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    if (!admin_login($email, $password)) {
        $error = 'Invalid email or password.';
    } else {
        header('Location: dashboard.php');
        exit;
    }
}

$missing = !is_file(admin_config_path());
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Login — Backlink Filler</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: system-ui, sans-serif; background: #0f172a; color: #e2e8f0; margin: 0; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
    .card { width: 100%; max-width: 400px; background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 28px; }
    h1 { margin: 0 0 8px; font-size: 1.25rem; }
    p { margin: 0 0 20px; color: #94a3b8; font-size: 0.9rem; }
    label { display: block; font-size: 0.8rem; margin-bottom: 6px; color: #cbd5e1; }
    input { width: 100%; padding: 10px 12px; border-radius: 8px; border: 1px solid #475569; background: #0f172a; color: #f8fafc; margin-bottom: 14px; }
    button { width: 100%; padding: 11px; border: 0; border-radius: 8px; background: #3b82f6; color: #fff; font-weight: 600; cursor: pointer; }
    button:hover { opacity: 0.92; }
    .err { background: #7f1d1d; color: #fecaca; padding: 10px 12px; border-radius: 8px; margin-bottom: 14px; font-size: 0.85rem; }
    .warn { background: #422006; color: #fde68a; padding: 10px 12px; border-radius: 8px; margin-bottom: 14px; font-size: 0.8rem; line-height: 1.4; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Admin panel</h1>
    <p>Backlink Filler — registered users</p>
    <?php if ($missing): ?>
      <div class="warn">Setup missing: upload <code>api/admin_config.php</code> (copy from <code>admin_config.sample.php</code>) with <code>ADMIN_EMAIL</code> and <code>ADMIN_PASSWORD_HASH</code>.</div>
    <?php endif; ?>
    <?php if ($error): ?><div class="err"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <form method="post" action="">
      <label for="email">Email</label>
      <input id="email" name="email" type="email" autocomplete="username" required />
      <label for="password">Password</label>
      <input id="password" name="password" type="password" autocomplete="current-password" required />
      <button type="submit">Sign in</button>
    </form>
  </div>
</body>
</html>

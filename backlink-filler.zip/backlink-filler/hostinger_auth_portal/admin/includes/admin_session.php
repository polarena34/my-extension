<?php
declare(strict_types=1);

function admin_config_path(): string
{
    return dirname(__DIR__, 2) . '/api/admin_config.php';
}

function admin_load_config(): array
{
    $path = admin_config_path();
    if (!is_file($path)) {
        return [];
    }
    $cfg = require $path;
    return is_array($cfg) ? $cfg : [];
}

function admin_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('bf_admin_sid');
    $cookiePath = '/';
    $sn = $_SERVER['SCRIPT_NAME'] ?? '';
    if ($sn !== '') {
        $dir = str_replace('\\', '/', dirname($sn));
        if ($dir !== '' && $dir !== '/') {
            $cookiePath = rtrim($dir, '/') . '/';
        }
    }
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => $cookiePath,
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function admin_is_logged_in(): bool
{
    admin_session_start();
    return !empty($_SESSION['bf_admin_ok']) && $_SESSION['bf_admin_ok'] === true;
}

function admin_require_login(): void
{
    if (!admin_is_logged_in()) {
        header('Location: index.php');
        exit;
    }
}

function admin_login(string $email, string $password): bool
{
    $cfg = admin_load_config();
    $wantEmail = strtolower(trim((string)($cfg['ADMIN_EMAIL'] ?? '')));
    $hash = (string)($cfg['ADMIN_PASSWORD_HASH'] ?? '');
    if ($wantEmail === '' || $hash === '' || strpos($hash, 'REPLACE') !== false) {
        return false;
    }
    if (strtolower(trim($email)) !== $wantEmail) {
        return false;
    }
    if (!password_verify($password, $hash)) {
        return false;
    }
    admin_session_start();
    session_regenerate_id(true);
    $_SESSION['bf_admin_ok'] = true;
    $_SESSION['bf_admin_email'] = $wantEmail;
    return true;
}

function admin_csrf_token(): string
{
    admin_session_start();
    if (empty($_SESSION['bf_admin_csrf'])) {
        $_SESSION['bf_admin_csrf'] = bin2hex(random_bytes(16));
    }
    return (string)$_SESSION['bf_admin_csrf'];
}

function admin_csrf_verify(?string $token): bool
{
    admin_session_start();
    $expected = $_SESSION['bf_admin_csrf'] ?? '';
    if ($expected === '' || $token === null || $token === '') {
        return false;
    }
    return hash_equals($expected, $token);
}

function admin_logout(): void
{
    admin_session_start();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

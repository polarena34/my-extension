(() => {
  const tabSignup = document.getElementById("tabSignup");
  const tabLogin = document.getElementById("tabLogin");
  const panelSignup = document.getElementById("panelSignup");
  const panelLogin = document.getElementById("panelLogin");
  const msg = document.getElementById("msg");

  const showMsg = (text, ok) => {
    msg.textContent = text;
    msg.className = "msg " + (ok ? "ok" : "err");
  };

  const setTab = (name) => {
    const signup = name === "signup";
    tabSignup.classList.toggle("active", signup);
    tabLogin.classList.toggle("active", !signup);
    panelSignup.classList.toggle("hidden", !signup);
    panelLogin.classList.toggle("hidden", signup);
    showMsg("", true);
  };

  tabSignup.addEventListener("click", () => setTab("signup"));
  tabLogin.addEventListener("click", () => setTab("login"));

  document.getElementById("btnSignup").addEventListener("click", async () => {
    const fullName = document.getElementById("signupName").value.trim();
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value;
    if (fullName.length < 2) {
      showMsg("Name is required (min 2 characters).", false);
      return;
    }
    try {
      const r = await fetch(window.AUTH_API_BASE + "/register.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ full_name: fullName, email, password })
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Signup failed");
      showMsg("Account created. Now login in extension popup.", true);
      setTab("login");
      document.getElementById("loginEmail").value = email;
    } catch (e) {
      showMsg(e.message || "Signup failed", false);
    }
  });

  document.getElementById("btnLogin").addEventListener("click", async () => {
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;
    try {
      const r = await fetch(window.AUTH_API_BASE + "/login.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Login failed");
      localStorage.setItem("bf_user_token", d.token);
      const okText =
        typeof window.BF_LOGIN_SUCCESS_MSG === "string" && window.BF_LOGIN_SUCCESS_MSG.trim()
          ? window.BF_LOGIN_SUCCESS_MSG.trim()
          : "Done — open the extension and log in there with the same details.";
      showMsg(okText, true);
    } catch (e) {
      showMsg(e.message || "Login failed", false);
    }
  });
})();

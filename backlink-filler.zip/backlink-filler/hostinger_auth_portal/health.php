<?php
header('Content-Type: text/plain; charset=utf-8');
echo "OK — PHP chal raha hai. Document root sahi hai.\n";
echo "Ab install.php bhi isi folder me honi chahiye.\n";

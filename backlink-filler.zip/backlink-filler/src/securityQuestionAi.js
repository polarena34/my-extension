// Security-question answers via server Groq proxy (same auth as comments).
var GROQ_MODEL_SQ = 'llama-3.3-70b-versatile';

function callSecurityAIBackend(userPrompt) {
  return new Promise(function (resolve) {
    if (typeof AUTH_API_BASE === 'undefined') {
      resolve({ ok: false, data: null });
      return;
    }
    chrome.storage.local.get(['accountAuthSession'], function (st) {
      var sess = st.accountAuthSession;
      if (!sess || !sess.token) {
        resolve({ ok: false, data: null });
        return;
      }
      if (sess.subscription_active === 0 || sess.subscription_active === false) {
        resolve({ ok: false, data: null });
        return;
      }
      fetch(AUTH_API_BASE + '/ai_chat.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + sess.token
        },
        body: JSON.stringify({
          model: GROQ_MODEL_SQ,
          messages: [{ role: 'user', content: userPrompt }],
          max_tokens: 64,
          temperature: 0.6
        })
      })
        .then(function (r) {
          return r.json().then(function (data) {
            return { ok: r.ok, data: data };
          });
        })
        .catch(function () {
          return { ok: false, data: null };
        })
        .then(resolve);
    });
  });
}

function extractSecurityText(data) {
  return (data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';
}

function cleanSecurityAnswer(raw) {
  if (!raw) return '';
  var t = String(raw).replace(/[\r\n]+/g, ' ').replace(/^['"]|['"]$/g, '').trim();
  t = t.replace(/^(answer|antwort|respuesta)\s*:\s*/i, '');
  if (t.length > 200) t = t.slice(0, 200);
  return t;
}

function fetchSecurityAnswerForQuestion(settings, questionBlockText) {
  var q = (questionBlockText || '').trim().slice(0, 1200);
  if (q.length < 3) return Promise.resolve(null);
  var prompt = [
    'You help with anonymous one-off forum/website sign-up "security" or "secret" questions (NOT passwords).',
    'The answer must be fictional but plausible, short, and easy to type again later.',
    'No real personal data. No profanity. No full sentences if a phrase is enough.',
    'Reply with ONLY the answer, 1–8 words, no quotes, no trailing period, English unless the question is clearly in another language (then answer in that language).',
    '',
    'Security / secret question (label and hints):',
    '"""' + q + '"""',
    '',
    'Answer only:'
  ].join('\n');
  return callSecurityAIBackend(prompt).then(function (r) {
    if (!r.ok || !r.data) return null;
    return cleanSecurityAnswer(extractSecurityText(r.data)) || null;
  });
}

// Runs in PAGE MAIN world inside Google's reCAPTCHA *anchor* iframe only (see manifest matches + exclude_matches on main bundle).
// Targets the real checkbox control: #recaptcha-anchor[role=checkbox] and .recaptcha-checkbox-border.

(function recaptchaAnchorAutoTick() {
  const path = (location.pathname || '').toLowerCase();
  if (/\/(bframe|bubble|challenge|reload|payload|webworker)/.test(path)) return;

  let stopped = false;
  let rounds = 0;
  const maxRounds = 50;

  function visibleEnough(el) {
    if (!el || !(el instanceof Element)) return false;
    try {
      const s = getComputedStyle(el);
      if (s.display === 'none' || s.visibility === 'hidden') return false;
      const r = el.getBoundingClientRect();
      return r.width >= 1 && r.height >= 1;
    } catch (_) {
      return false;
    }
  }

  function anchorSpan() {
    const el = document.querySelector('#recaptcha-anchor');
    if (el && (el.getAttribute('role') || '').toLowerCase() === 'checkbox') return el;
    return null;
  }

  function findInnerClickable() {
    return (
      document.querySelector('.recaptcha-checkbox-border')
      || document.querySelector('.rc-anchor-checkbox-holder')
      || document.querySelector('#recaptcha-anchor .recaptcha-checkbox-border')
    );
  }

  function isDone() {
    const a = anchorSpan();
    if (a && String(a.getAttribute('aria-checked')).toLowerCase() === 'true') return true;
    if (document.querySelector('.recaptcha-checkbox-checked')) return true;
    if (document.querySelector('.recaptcha-checkbox.goog-inline-block.recaptcha-checkbox-checked')) return true;
    return false;
  }

  function centerCoords(el) {
    const r = el.getBoundingClientRect();
    const x = Math.floor(r.left + r.width / 2);
    const y = Math.floor(r.top + r.height / 2);
    return { x, y, r };
  }

  function firePointerChain(el) {
    const { x, y } = centerCoords(el);
    const common = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, screenX: x + window.screenX, screenY: y + window.screenY, button: 0 };
    try {
      el.scrollIntoView({ block: 'center', inline: 'nearest' });
    } catch (_) { /* */ }
    try {
      if (typeof PointerEvent === 'function') {
        el.dispatchEvent(new PointerEvent('pointerover', { ...common, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
        el.dispatchEvent(new PointerEvent('pointerenter', { ...common, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
        el.dispatchEvent(new PointerEvent('pointerdown', { ...common, pointerId: 1, pointerType: 'mouse', isPrimary: true, buttons: 1 }));
        el.dispatchEvent(new PointerEvent('pointerup', { ...common, pointerId: 1, pointerType: 'mouse', isPrimary: true, buttons: 0 }));
      }
      el.dispatchEvent(new MouseEvent('mouseover', { ...common, buttons: 0 }));
      el.dispatchEvent(new MouseEvent('mouseenter', { ...common, buttons: 0 }));
      el.dispatchEvent(new MouseEvent('mousedown', { ...common, buttons: 1 }));
      el.dispatchEvent(new MouseEvent('mouseup', { ...common, buttons: 0 }));
      el.dispatchEvent(new MouseEvent('click', { ...common, buttons: 0 }));
      if (typeof el.click === 'function') el.click();
    } catch (_) { /* */ }
  }

  function fireSpaceOn(el) {
    try {
      el.focus();
    } catch (_) { /* */ }
    try {
      el.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', code: 'Space', keyCode: 32, which: 32, bubbles: true, cancelable: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { key: ' ', code: 'Space', keyCode: 32, which: 32, bubbles: true, cancelable: true }));
    } catch (_) { /* */ }
  }

  function tryTick() {
    if (stopped) return true;
    if (isDone()) {
      stopped = true;
      return true;
    }

    const span = anchorSpan();
    const inner = findInnerClickable();
    const primary = (span && visibleEnough(span) && span) || (inner && visibleEnough(inner) && inner);
    if (!primary) return false;

    if (rounds >= maxRounds) {
      stopped = true;
      return true;
    }
    rounds++;

    if (inner && visibleEnough(inner)) firePointerChain(inner);
    else firePointerChain(primary);

    if (span && span !== primary) firePointerChain(span);

    fireSpaceOn(span || primary);

    return isDone();
  }

  function run() {
    if (tryTick()) return;
    const obs = new MutationObserver(() => {
      if (tryTick()) try { obs.disconnect(); } catch (_) { /* */ }
    });
    try {
      obs.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'aria-checked'] });
    } catch (_) { /* */ }

    let n = 0;
    const id = setInterval(() => {
      if (tryTick() || ++n > 120) {
        clearInterval(id);
        stopped = true;
        try { obs.disconnect(); } catch (_) { /* */ }
      }
    }, 130);

    setTimeout(() => {
      try { obs.disconnect(); } catch (_) { /* */ }
    }, 25000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => requestAnimationFrame(() => requestAnimationFrame(run)), { once: true });
  } else {
    requestAnimationFrame(() => requestAnimationFrame(run));
  }
})();

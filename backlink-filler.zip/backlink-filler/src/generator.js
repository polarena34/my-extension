// ── Random Data Generator ─────────────────────────────────────────────────────

const FIRST_NAMES = [
  'James','Robert','Michael','William','David','Richard','Joseph','Thomas',
  'Charles','Daniel','Matthew','Anthony','Mark','Donald','Steven','Paul',
  'Andrew','Joshua','Kenneth','Kevin','Brian','George','Edward','Ronald',
  'Timothy','Jason','Jeffrey','Ryan','Jacob','Gary','Nicholas','Eric',
  'Stephen','Jonathan','Larry','Justin','Scott','Brandon','Frank','Raymond',
  'Mary','Patricia','Jennifer','Linda','Barbara','Susan','Jessica','Sarah',
  'Karen','Lisa','Nancy','Betty','Margaret','Sandra','Ashley','Dorothy',
  'Kimberly','Emily','Donna','Michelle','Carol','Amanda','Melissa','Deborah',
  'Stephanie','Rebecca','Sharon','Laura','Cynthia','Kathleen','Amy','Angela'
];

const LAST_NAMES = [
  'Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis',
  'Rodriguez','Martinez','Hernandez','Lopez','Gonzalez','Wilson','Anderson',
  'Thomas','Taylor','Moore','Jackson','Martin','Lee','Perez','Thompson',
  'White','Harris','Sanchez','Clark','Ramirez','Lewis','Robinson','Walker',
  'Young','Allen','King','Wright','Scott','Torres','Nguyen','Hill','Flores',
  'Green','Adams','Nelson','Baker','Hall','Rivera','Campbell','Mitchell',
  'Carter','Roberts','Turner','Phillips','Evans','Collins','Stewart','Morris'
];

const COUNTRIES = [
  'United States', 'United Kingdom', 'Canada', 'Australia',
  'Germany', 'France', 'Netherlands', 'Sweden', 'Norway',
  'Denmark', 'Finland', 'Austria', 'Switzerland', 'Belgium',
  'New Zealand', 'Ireland', 'Portugal', 'Spain', 'Italy'
];

// Random city (pairs reasonably with our country set; for forms that need a city)
const CITIES = [
  'Houston', 'Chicago', 'Manchester', 'Birmingham', 'Glasgow', 'Toronto', 'Vancouver', 'Sydney', 'Melbourne', 'Auckland',
  'Berlin', 'Munich', 'Frankfurt', 'Hamburg', 'Paris', 'Lyon', 'Madrid', 'Barcelona', 'Rome', 'Milan', 'Dublin', 'Cork',
  'Amsterdam', 'Rotterdam', 'Brussels', 'Stockholm', 'Oslo', 'Copenhagen', 'Helsinki', 'Vienna', 'Zurich', 'Geneva',
  'Dubai', 'Lisbon', 'Lagos', 'Nairobi', 'Karachi', 'Istanbul', 'Bristol', 'Liverpool', 'Leeds', 'Nottingham',
  'Montreal', 'Ottawa', 'Calgary', 'Perth', 'Brisbane', 'Edinburgh', 'Newcastle', 'Bournemouth', 'Bath', 'Sheffield'
];

const ADJECTIVES = [
  'quick','bright','calm','bold','swift','sharp','cool','keen',
  'smart','wise','fast','pure','clear','fresh','grand','prime'
];

const NOUNS = [
  'wolf','fox','hawk','lion','bear','tiger','eagle','shark',
  'blade','storm','rock','fire','wave','leaf','star','peak'
];

function rand(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateUniqueSet(generatorFn, count = 5) {
  const results = new Set();
  let attempts = 0;
  while (results.size < count && attempts < 100) {
    results.add(generatorFn());
    attempts++;
  }
  return [...results];
}

// ── Name generators ───────────────────────────────────────────────────────────

function generateFirstName() { return rand(FIRST_NAMES); }
function generateLastName()  { return rand(LAST_NAMES); }

function generateUsername() {
  const style = randInt(0, 4);
  const fn = rand(FIRST_NAMES).toLowerCase();
  const ln = rand(LAST_NAMES).toLowerCase();
  const num = randInt(10, 9999);
  const adj = rand(ADJECTIVES);
  const noun = rand(NOUNS);

  switch (style) {
    case 0: return fn + ln.slice(0, randInt(2,4)) + num;
    case 1: return fn + '_' + ln.slice(0, 3) + randInt(10, 99);
    case 2: return adj + '_' + noun + randInt(1, 99);
    case 3: return fn.slice(0, 1) + ln + randInt(100, 999);
    case 4: return noun + fn.slice(0, 3) + num;
    default: return fn + num;
  }
}

function generatePassword() {
  const lower  = 'abcdefghijklmnopqrstuvwxyz';
  const upper  = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const digits = '0123456789';
  const special = '!@#$%^&*';

  // Guarantee at least 1 of each type
  let pwd = [
    lower[randInt(0, lower.length - 1)],
    upper[randInt(0, upper.length - 1)],
    digits[randInt(0, digits.length - 1)],
    special[randInt(0, special.length - 1)],
  ];

  const all = lower + upper + digits + special;
  for (let i = 0; i < 10; i++) pwd.push(all[randInt(0, all.length - 1)]);

  // Shuffle
  for (let i = pwd.length - 1; i > 0; i--) {
    const j = randInt(0, i);
    [pwd[i], pwd[j]] = [pwd[j], pwd[i]];
  }
  return pwd.join('');
}

function generateCountry() { return rand(COUNTRIES); }
function generateCity() { return rand(CITIES); }

const US_STATES = [
  'California', 'Texas', 'Florida', 'New York', 'Illinois', 'Pennsylvania', 'Ohio', 'Georgia', 'North Carolina', 'Michigan',
  'New Jersey', 'Virginia', 'Washington', 'Arizona', 'Massachusetts', 'Tennessee', 'Indiana', 'Missouri', 'Maryland', 'Wisconsin',
];

const STREET_NAMES = [
  'Main', 'Oak', 'Maple', 'Cedar', 'Pine', 'Elm', 'Lake', 'Hill', 'Park', 'River', 'Sunset', 'Mill', 'Church', 'Walnut', 'Highland', 'King', 'Second', 'Broadway',
];

const STREET_SUFFIXES = ['St', 'Street', 'Rd', 'Road', 'Ave', 'Avenue', 'Blvd', 'Ln', 'Drive', 'Way', 'Court', 'Plaza'];

function generateAddressLine1() {
  return `${randInt(12, 9999)} ${rand(STREET_NAMES)} ${rand(STREET_SUFFIXES)}`;
}

function generateAddressLine2() {
  return `Apt ${randInt(1, 500)}`;
}

function generateStateRegion(country) {
  const c = country || '';
  if (c === 'United States') return rand(US_STATES);
  if (c === 'United Kingdom') return rand(['England', 'Scotland', 'Wales', 'Northern Ireland', 'Greater London']);
  if (c === 'Canada') return rand(['Ontario', 'British Columbia', 'Alberta', 'Quebec', 'Manitoba']);
  if (c === 'Australia') return rand(['New South Wales', 'Victoria', 'Queensland', 'Western Australia', 'South Australia']);
  if (c === 'Germany') return rand(['Bavaria', 'North Rhine-Westphalia', 'Baden-Württemberg', 'Lower Saxony', 'Hesse']);
  if (c === 'France') return rand(['Île-de-France', 'Provence-Alpes-Côte d\'Azur', 'Auvergne-Rhône-Alpes', 'Occitanie']);
  if (c === 'Spain') return rand(['Andalusia', 'Catalonia', 'Madrid', 'Valencia', 'Galicia']);
  if (c === 'Italy') return rand(['Lombardy', 'Lazio', 'Campania', 'Sicily', 'Veneto']);
  if (c === 'Netherlands') return rand(['North Holland', 'South Holland', 'North Brabant', 'Utrecht', 'Gelderland']);
  if (c === 'Sweden') return rand(['Stockholm', 'Västra Götaland', 'Skåne', 'Uppsala']);
  if (c === 'Ireland') return rand(['Leinster', 'Munster', 'Connacht', 'Ulster']);
  if (c === 'New Zealand') return rand(['Auckland', 'Wellington', 'Canterbury', 'Waikato']);
  if (c === 'Portugal') return rand(['Lisbon', 'Porto', 'Braga', 'Faro']);
  if (c === 'Belgium') return rand(['Flanders', 'Wallonia', 'Brussels']);
  if (c === 'Switzerland') return rand(['Zurich', 'Bern', 'Vaud', 'Geneva']);
  if (c === 'Austria') return rand(['Vienna', 'Tyrol', 'Styria', 'Upper Austria']);
  if (c === 'Denmark' || c === 'Norway' || c === 'Finland') return c;
  return c || rand(US_STATES);
}

function generatePostalCode(country) {
  const c = country || '';
  if (c === 'United States') return String(randInt(10001, 99950));
  if (c === 'Canada') {
    const letters = 'ABCEGHJKLMNPRSTVWXYZ';
    const L = () => letters[randInt(0, letters.length - 1)];
    const d = () => String(randInt(0, 9));
    return `${L()}${d()}${L()} ${d()}${L()}${d()}`;
  }
  if (c === 'United Kingdom') {
    const outs = ['SW1A', 'M1', 'B33', 'EC1A', 'W1A', 'LN1', 'CB2', 'EH1', 'G1'];
    const ins = ['1AA', '2AB', '3JQ', '9ZZ', '8XY', '4GH', '7DE', '5RT'];
    return `${rand(outs)} ${rand(ins)}`;
  }
  if (c === 'Netherlands') {
    const n = randInt(1000, 9999);
    const a = () => String.fromCharCode(65 + randInt(0, 25)) + String.fromCharCode(65 + randInt(0, 25));
    return `${n}${a()}`;
  }
  if (['Germany', 'France', 'Italy', 'Spain', 'Austria', 'Switzerland', 'Belgium', 'Sweden', 'Norway', 'Denmark', 'Finland'].includes(c)) {
    return String(randInt(10000, 99999));
  }
  if (c === 'Australia') return String(randInt(2000, 9999));
  if (c === 'Ireland') return rand(['D02 XY45', 'D01 F5P3', 'C15 DK48', 'H91 V1Y2', 'T12 R6C8']);
  if (c === 'New Zealand') return String(randInt(1000, 2999));
  if (c === 'Portugal') return String(randInt(1000, 9999)) + '-' + String(randInt(100, 999));
  return String(randInt(10000, 99999));
}

// Short vehicle / model (e.g. e-scooter forums: VMP, model type)
const VMP_MODELS = [
  'M365 PRO', 'M365', 'Ninebot Max G30', 'Xiaomi Pro 2', 'Segway Ninebot F40',
  'Dualtron Mini', 'Kaabo Mantis', 'Inmotion V10', 'Gotrax G4', 'Cecotec Bongo'
];

function generateVmp() { return rand(VMP_MODELS); }

function generateDobComponents() {
  // Before 2005, valid calendar day (adult-age spread)
  const y = randInt(1970, 2004);
  const m = randInt(1, 12);
  const dMax = new Date(y, m, 0).getDate();
  const d = randInt(1, dMax);
  return { y, m, d };
}

// ── Profile builder ───────────────────────────────────────────────────────────

function generateProfile(email, website) {
  const firstName = generateFirstName();
  const lastName  = generateLastName();
  const username  = generateUsername();
  const country = generateCountry();
  const city = generateCity();
  const { y: birthYear, m: birthMonth, d: birthDay } = generateDobComponents();
  const pad2 = (n) => (n < 10 ? '0' : '') + n;
  const pM = pad2(birthMonth);
  const pD = pad2(birthDay);
  const dobIso = `${birthYear}-${pM}-${pD}`;

  return {
    firstName,
    lastName,
    fullName:    firstName + ' ' + lastName,
    displayName: username,
    username,
    email,
    password:    generatePassword(),
    website:     website || '',
    country,
    city,
    stateRegion: generateStateRegion(country),
    postalCode:  generatePostalCode(country),
    addressLine1: generateAddressLine1(),
    addressLine2: generateAddressLine2(),
    vmp:         generateVmp(),
    birthYear,
    birthMonth,
    birthDay,
    dobIso,
    dobUs:  `${pM}/${pD}/${birthYear}`,
    dobEu:  `${pD}/${pM}/${birthYear}`,
    dobDe:  `${pD}.${pM}.${birthYear}`,
  };
}

// Export for use in other scripts
if (typeof module !== 'undefined') module.exports = { generateProfile };

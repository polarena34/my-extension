// Shared auth + AI API base (popup + content scripts). Update if your site URL changes.
var AUTH_SITE_BASE = 'https://grey-cormorant-148451.hostingersite.com';
var AUTH_API_BASE = AUTH_SITE_BASE + '/api';

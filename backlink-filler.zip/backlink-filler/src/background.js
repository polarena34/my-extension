// Service worker — context menu → ask the active tab's content script to fill using stored profile.

function registerContextMenus() {
  chrome.contextMenus.removeAll(() => {
    try {
      chrome.contextMenus.create({
        id: 'bff-fill-form',
        title: 'Fill form with Backlink Form Filler',
        contexts: ['page', 'frame', 'editable'],
      });
    } catch (_) { /* */ }
  });
}

chrome.runtime.onInstalled.addListener(registerContextMenus);
registerContextMenus();

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== 'bff-fill-form' || tab == null || tab.id == null) return;
  const url = tab.url || '';
  if (!/^https?:\/\//i.test(url)) return;

  chrome.tabs.sendMessage(tab.id, { action: 'fillFormFromMenu' }, () => {
    void chrome.runtime.lastError;
  });
});

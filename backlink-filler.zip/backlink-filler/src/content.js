// Content script — injected on every page

let currentProfile = null;

/** Some pages (e.g. Google SERP) can throw or set lastError on storage; never crash the content script. */
function storageLocalGet(keys, callback) {
  try {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local || typeof chrome.storage.local.get !== 'function') {
      callback({});
      return;
    }
    chrome.storage.local.get(keys, (res) => {
      if (chrome.runtime && chrome.runtime.lastError) {
        callback({});
        return;
      }
      callback(res != null ? res : {});
    });
  } catch (_) {
    callback({});
  }
}

function storageLocalSetSafe(obj, done) {
  try {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local || typeof chrome.storage.local.set !== 'function') {
      if (done) done();
      return;
    }
    chrome.storage.local.set(obj, () => {
      void (chrome.runtime && chrome.runtime.lastError);
      if (done) done();
    });
  } catch (_) {
    if (done) done();
  }
}

/** Reading .value on some third-party / search-page inputs can throw; never break credential heuristics. */
function safeInputValue(el) {
  try {
    if (!el || el.nodeType !== 1) return '';
    const tag = (el.tagName || '').toUpperCase();
    if (tag !== 'INPUT' && tag !== 'TEXTAREA') return '';
    const v = el.value;
    return v == null ? '' : String(v);
  } catch (_) {
    return '';
  }
}

function safeInputType(el) {
  try {
    const t = el && el.type;
    return String(t != null ? t : 'text').toLowerCase();
  } catch (_) {
    return 'text';
  }
}

/** Email fields always use Settings "Your Email" when set (cached profile may still hold an older email). */
function applySettingsEmailToProfile(profile, settingsEmail) {
  if (!profile) return profile;
  const e = String(settingsEmail || '').trim();
  if (!e) return profile;
  return Object.assign({}, profile, { email: e });
}

/** Active subscription — server AI, scan helpers, page read for comments, etc. */
function accountSessionAllowsUse(sess) {
  if (!sess || !sess.token) return false;
  if (sess.subscription_active === 0 || sess.subscription_active === false) return false;
  return true;
}

/** Logged in with a valid token — form autofill & manual fill work even during billing trial / subscription OFF. */
function accountSessionSignedIn(sess) {
  return !!(sess && sess.token);
}

// ── Message listener ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'fillForm') {
    storageLocalGet(['accountAuthSession', 'settings'], (ga) => {
      if (!accountSessionSignedIn(ga.accountAuthSession)) {
        sendResponse({
          success: false,
          filled: 0,
          error: 'auth_required'
        });
        return;
      }
      if (shouldSkipFillBecauseSavedCredentials()) {
        sendResponse({ success: true, filled: 0, skipped: 'saved_credentials_detected', siteKey: normalizeSiteKey(location.hostname) });
        return;
      }
      const profile = applySettingsEmailToProfile(msg.profile, ga.settings && ga.settings.email);
      currentProfile = profile;
      const filled = fillForm(profile);
      setTimeout(() => { fillForm(profile); }, 500);
      setTimeout(() => { tryPostFillCaptchaAssist(); }, 700);
      setTimeout(() => { tryPostFillCaptchaAssist(); }, 2000);
      sendResponse({ success: true, filled, siteKey: normalizeSiteKey(location.hostname) });
      if (ga.settings) {
        fillSecurityQuestionsWithAI(ga.settings, profile);
        setTimeout(() => fillSecurityQuestionsWithAI(ga.settings, profile), 2500);
      }
    });
    return true;
  }

  if (msg.action === 'fillFormFromMenu') {
    storageLocalGet('accountAuthSession', (ga) => {
      if (!accountSessionSignedIn(ga.accountAuthSession)) {
        sendResponse({
          success: false,
          filled: 0,
          error: 'auth_required'
        });
        return;
      }
      if (location.protocol !== 'http:' && location.protocol !== 'https:') {
        sendResponse({ success: false, filled: 0, error: 'bad_protocol' });
        return;
      }
      if (shouldSkipFillBecauseSavedCredentials()) {
        sendResponse({ success: true, filled: 0, skipped: 'saved_credentials_detected', siteKey: normalizeSiteKey(location.hostname) });
        return;
      }
      storageLocalGet(['settings', 'siteProfiles', 'activeProfile'], (data) => {
      const s = data.settings || {};
      const email = String(s.email || '').trim();
      const siteKey = normalizeSiteKey(location.hostname);
      const siteProfiles = Object.assign({}, data.siteProfiles || {});
      let profile = siteProfiles[siteKey] || data.activeProfile;
      if (!profile && email) {
        profile = generateProfile(email, s.website || '');
      }
      if (!profile) {
        sendResponse({ success: false, filled: 0, error: 'no_profile_set_email' });
        return;
      }
      profile = applySettingsEmailToProfile(profile, email);
      currentProfile = profile;
      const filled = fillForm(profile);
      setTimeout(() => { fillForm(profile); }, 500);
      setTimeout(() => { tryPostFillCaptchaAssist(); }, 700);
      setTimeout(() => { tryPostFillCaptchaAssist(); }, 2000);
      siteProfiles[siteKey] = profile;
      storageLocalSetSafe({ siteProfiles, activeProfile: profile, activeProfileForSite: siteKey });
      if (s.email) {
        fillSecurityQuestionsWithAI(s, profile);
        setTimeout(() => fillSecurityQuestionsWithAI(s, profile), 2500);
      }
      sendResponse({ success: true, filled, siteKey, persisted: true });
      });
    });
    return true;
  }

  if (msg.action === 'scanFields') {
    storageLocalGet('accountAuthSession', (ga) => {
      if (!accountSessionAllowsUse(ga.accountAuthSession)) {
        sendResponse({
          fields: [],
          error: !ga.accountAuthSession || !ga.accountAuthSession.token ? 'auth_required' : 'subscription_inactive'
        });
        return;
      }
      sendResponse({ fields: scanFormFields() });
    });
    return true;
  }
  if (msg.action === 'getPageContent') {
    storageLocalGet('accountAuthSession', (ga) => {
      if (!accountSessionAllowsUse(ga.accountAuthSession)) {
        sendResponse({
          content: null,
          error: !ga.accountAuthSession || !ga.accountAuthSession.token ? 'auth_required' : 'subscription_inactive'
        });
        return;
      }
      sendResponse({ content: extractPageContent() });
    });
    return true;
  }
  return false;
});

// ── Page content extractor ────────────────────────────────────────────────────

function extractPageContent() {
  // Prefer article-like containers and ignore noisy UI blocks.
  const selectors = [
    'article',
    'main article',
    '[role="main"] article',
    '.post-content',
    '.entry-content',
    '.article-content',
    '.article-body',
    '.post-body',
    '.blog-post',
    '#content article',
    'main',
    '#main',
    '#content'
  ];

  const noiseSelectors = [
    'script', 'style', 'noscript', 'nav', 'header', 'footer', 'aside',
    '.sidebar', '.widget', '.menu', '.breadcrumb', '.comments', '.comment-respond',
    '.related', '.share', '.social', '.newsletter', '.pagination', '.ads', '.ad'
  ];

  let sourceEl = null;
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el && (el.innerText || '').trim().length > 250) {
      sourceEl = el;
      break;
    }
  }

  if (!sourceEl) sourceEl = document.body;

  // Clone and strip noisy blocks so model sees topical content.
  const clone = sourceEl.cloneNode(true);
  noiseSelectors.forEach(sel => {
    clone.querySelectorAll(sel).forEach(n => n.remove());
  });

  const title = (document.title || '').trim();
  const h1 = (document.querySelector('h1')?.innerText || '').trim();

  const paragraphs = Array.from(clone.querySelectorAll('p'))
    .map(p => (p.innerText || '').replace(/\s+/g, ' ').trim())
    .filter(p => p.length > 60)
    .slice(0, 6);

  let text = paragraphs.join(' ');
  if (!text) {
    text = (clone.innerText || '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Keep enough context without sending overly large prompts.
  const cleaned = text.slice(0, 3500);

  return { title, h1, body: cleaned };
}

// ── Terms / policy checkboxes (not newsletter / marketing) ───────────────────

function getCheckboxContextBits(field) {
  const parts = [field.name, field.id, field.placeholder || '', field.getAttribute('aria-label') || '', field.getAttribute('title') || ''];
  const wrap = field.closest('label, .formRow, .formButtonGroup, li, tr, dd, [class*="formRow"], [class*="inputGroup"], .form-group, .block, fieldset');
  if (wrap) {
    parts.push((wrap.innerText || '').slice(0, 600));
  }
  return parts.join(' ').toLowerCase();
}

function isHumanVerificationCheckbox(field, all, labelText) {
  // Same-page checkboxes only. Google reCAPTCHA / hCaptcha / Turnstile usually live in cross-origin iframes — those cannot be ticked from this script; use manual solve for image challenges.
  const ctx = (all + ' ' + getLabelText(field) + ' ' + getCheckboxContextBits(field)).toLowerCase();
  if (/(newsletter|subscribe\s*to(\s*our)?\s*mail|email\s*me(\s*offers?)?|marketing|promo(tion)?s?|remember\s*me|stay\s*(signed|logged))/.test(ctx) && !/(robot|not a robot|human|captcha|verify|bot( )?check|security)/.test(ctx)) {
    return false;
  }
  if (/(not a robot|not\s*robot|i( a)?m not a robot|i'm not a robot|i am human|i'm human|i am a human|verify you are human|verify that you|prove you(’|')?re human|are you human|no soy un robot|verificar( que)? (no )?eres humano|je ne suis pas un robot|ich bin (kein|nicht) (ein )?robot|h[\s-]?captcha|cf[\s-]?turnstile|turnstile|cloudflare(\s*security)?|human verif|security check|bot check|i('| a)m not a|confirm( you are)? human|human verification|captcha verification|verify\s*you(\s*are)?\s*not\s*a\s*bot|not\s*a\s*bot|insaan|robot nahi|mai(n)?\s*insaan)/.test(ctx)) {
    return true;
  }
  const idn = ((field.name || '') + ' ' + (field.id || '')).toLowerCase();
  if (/(^|_)(captcha|hcaptcha|turnstile|human(_)?verif|verify_human|not[_-]?robot|iamhuman|iamnotrobot|botcheck|bot[_-]?check)($|_)/.test(idn) && !/(newsletter|mailing|terms_)/.test(idn)) {
    return true;
  }
  return false;
}

function isTermsOrPolicyCheckbox(field, all, labelText) {
  const ctx = (all + ' ' + getLabelText(field) + ' ' + getCheckboxContextBits(field)).toLowerCase();
  if (/(newsletter|marketing|promo(tion)?s?|email\s*alerts?|send\s*me\s*(_)?(emails?|offers?)|subscribe\s*to( our)?\s*mail|opt[\s-]*in|third[\s-]?party|partner(\s*offers?)?|deal(s)?\b|special\s*offers?|surveys?|remember\s*me|stay\s*(signed|logged)|save(\s*my)?\s*(info|password)|honeypot|consent.*ads)/.test(ctx)) {
    return false;
  }
  if (/(terms|conditions|condiciones|t(é|e)rminos|privacy|pol(í|i)tica|politica|policy|gdpr|agreement|user[\s-]agreement|legal(\s*notice|s)?|disclaimer|rules|term(s)?\s*of(\s*service|\s*use)?|\btos\b|t(é|e)rminos|age\s*verification|18\+|i(\s*)?('?ve| have)\s*read|read\s*(and\s*)?(accept|agree)|acepto(\s*los| las| el)?|accept(\s*the)?\s*(terms|rules|policy|conditions)?|acknowledge|must\s*agree|acept(o|ar)\s*los|obligator.*(t(é|e)rmin|condic|pol(í|i)tica))/.test(ctx)) {
    return true;
  }
  const idn = ((field.name || '') + ' ' + (field.id || '')).toLowerCase();
  if (/(^|_)(accept|agree|terms|tos|tac|policy|privacy|legal|rules|conditions|register_rules|agb|consent|tnc|t&c)($|_)/.test(idn) && !/(newsletter|promo|marketing|email|mailing|opt)/.test(idn)) {
    return true;
  }
  return false;
}

function setCheckboxChecked(field) {
  if (field.disabled) return;
  if (field.checked) return;
  try {
    const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'checked');
    if (d && d.set) d.set.call(field, true);
    else field.checked = true;
  } catch {
    field.checked = true;
  }
  field.dispatchEvent(new Event('input', { bubbles: true }));
  field.dispatchEvent(new Event('change', { bubbles: true }));
}

/** Visible in viewport (rough) — used before synthetic captcha clicks */
function isLikelyVisibleForClick(el) {
  if (!el || !(el instanceof Element)) return false;
  try {
    const st = window.getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden' || parseFloat(st.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return false;
    if (r.bottom < -20 || r.top > window.innerHeight + 20 || r.right < -20 || r.left > window.innerWidth + 20) return false;
  } catch (_) {
    return false;
  }
  return true;
}

/**
 * Human / “not a robot” style checkboxes often ignore programmatic .checked until a real click path runs.
 * Same-document only — reCAPTCHA/hCaptcha iframes on google.com / hcaptcha.com stay out of reach.
 */
function setCheckboxCheckedWithHumanClick(field) {
  if (!field || field.disabled) return;
  try {
    field.scrollIntoView({ block: 'center', inline: 'nearest' });
  } catch (_) { /* */ }
  if (field.id) {
    const lab = document.querySelector(`label[for="${CSS.escape(field.id)}"]`);
    if (lab && isLikelyVisibleForClick(lab)) {
      try { lab.click(); } catch (_) { /* */ }
    }
  }
  const wrap = field.closest('label');
  if (wrap && isLikelyVisibleForClick(wrap)) {
    try { wrap.click(); } catch (_) { /* */ }
  }
  try {
    field.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, view: window }));
    field.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window, button: 0, buttons: 1 }));
    field.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window, button: 0, buttons: 0 }));
    field.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window, button: 0, buttons: 0 }));
    if (typeof field.click === 'function') field.click();
  } catch (_) { /* */ }
  if (!field.checked) setCheckboxChecked(field);
}

/** Extra pass: shadow-root checkboxes (some Turnstile / custom widgets) + ARIA checkbox buttons on the host page only */
function tryPostFillCaptchaAssist() {
  let n = 0;
  const hostSel = 'cf-turnstile, [class*="turnstile" i], [class*="hcaptcha" i], [class*="captcha" i], [id*="captcha" i], [class*="g-recaptcha" i]';
  try {
    document.querySelectorAll(hostSel).forEach((host) => {
      if (!host.shadowRoot) return;
      host.shadowRoot.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
        if (cb.disabled || cb.checked) return;
        const name = (cb.name || '').toLowerCase();
        const id = (cb.id || '').toLowerCase();
        const al = (cb.getAttribute('aria-label') || '').toLowerCase();
        const all = [name, id, al].join(' ');
        if (isHumanVerificationCheckbox(cb, all, '') || /(robot|human|captcha|verify|turnstile|cloudflare|hcaptcha)/.test(all + ' ' + getCheckboxContextBits(cb))) {
          setCheckboxCheckedWithHumanClick(cb);
          n++;
        }
      });
    });
  } catch (_) { /* */ }

  try {
    document.querySelectorAll('[role="checkbox"][aria-checked="false"]').forEach((el) => {
      const t = ((el.getAttribute('aria-label') || '') + ' ' + (el.textContent || '')).toLowerCase();
      if (!/(robot|captcha|human|verify|security|cloudflare|turnstile|hcaptcha|not a robot)/.test(t)) return;
      if (!isLikelyVisibleForClick(el)) return;
      try {
        el.scrollIntoView({ block: 'center', inline: 'nearest' });
        el.click();
        n++;
      } catch (_) { /* */ }
    });
  } catch (_) { /* */ }

  try {
    document.querySelectorAll('button[aria-label*="not a robot" i], [role="button"][aria-label*="not a robot" i], button[aria-label*="human" i][aria-label*="verify" i]').forEach((btn) => {
      if (!isLikelyVisibleForClick(btn)) return;
      try {
        btn.scrollIntoView({ block: 'center', inline: 'nearest' });
        btn.click();
        n++;
      } catch (_) { /* */ }
    });
  } catch (_) { /* */ }

  return n;
}

// ── Fill ──────────────────────────────────────────────────────────────────────

function fillForm(profile) {
  const inputs = document.querySelectorAll('input, textarea, select');
  let filled = 0;

  inputs.forEach(field => {
    const value = detectAndGetValue(field, profile);
    if (value === true && (field.type || '').toLowerCase() === 'checkbox') {
      const name = (field.name || '').toLowerCase();
      const id = (field.id || '').toLowerCase();
      const placeholder = (field.placeholder || '').toLowerCase();
      const autocomplete = (field.autocomplete || '').toLowerCase();
      const labelText = getLabelText(field).toLowerCase();
      const ariaLabel = (field.getAttribute('aria-label') || '').toLowerCase();
      const title = (field.getAttribute('title') || '').toLowerCase();
      const dataLabel = (field.getAttribute('data-label') || '').toLowerCase();
      const all = [name, id, placeholder, autocomplete, labelText, ariaLabel, title, dataLabel].join(' ');
      if (isHumanVerificationCheckbox(field, all, labelText)) {
        setCheckboxCheckedWithHumanClick(field);
      } else {
        setCheckboxChecked(field);
      }
      filled++;
      return;
    }
    if (value !== null && value !== undefined && value !== '') {
      setNativeValue(field, value);
      filled++;
    }
  });

  // Fallback: mature handling for mixed DOB UI (month <select> + day/year inputs).
  filled += fillHybridDobGaps(profile);

  filled += tryPostFillCaptchaAssist();

  return filled;
}

// ── Location fields (address / geo) — autocomplete + many naming conventions ──

function simpleHash(s) {
  let h = 0;
  const str = String(s || '');
  for (let i = 0; i < str.length; i++) h = Math.imul(31, h) + str.charCodeAt(i) | 0;
  return Math.abs(h);
}

function profileLocationResolved(profile) {
  const city = profile.city || '';
  const country = profile.country || '';
  const email = profile.email || '';
  return {
    city,
    country,
    postal: profile.postalCode || String(10000 + (simpleHash(`${email}|zip|${country}`) % 90000)),
    state: profile.stateRegion || deriveStateFallback(profile),
    line1: profile.addressLine1 || deriveAddressLine1Fallback(profile),
    line2: profile.addressLine2 || `Suite ${50 + (simpleHash(`${email}|a2`) % 900)}`,
  };
}

function deriveStateFallback(profile) {
  const c = profile.country || '';
  const pools = {
    'United States': ['California', 'Texas', 'Florida', 'New York', 'Illinois', 'Pennsylvania', 'Ohio', 'Georgia'],
    'United Kingdom': ['England', 'Scotland', 'Wales', 'Northern Ireland'],
    'Canada': ['Ontario', 'British Columbia', 'Alberta', 'Quebec'],
    'Germany': ['Bavaria', 'North Rhine-Westphalia', 'Baden-Württemberg', 'Hesse'],
    'Spain': ['Andalusia', 'Catalonia', 'Madrid', 'Valencia'],
    'Italy': ['Lombardy', 'Lazio', 'Campania', 'Veneto'],
    'France': ['Île-de-France', 'Occitanie', 'Auvergne-Rhône-Alpes'],
    'Netherlands': ['North Holland', 'South Holland', 'Utrecht', 'North Brabant'],
    'Australia': ['New South Wales', 'Victoria', 'Queensland'],
    'India': ['Maharashtra', 'Karnataka', 'Delhi', 'Tamil Nadu'],
    'Pakistan': ['Punjab', 'Sindh', 'Khyber Pakhtunkhwa'],
    'Turkey': ['Istanbul', 'Ankara', 'İzmir', 'Antalya'],
    'Indonesia': ['Jakarta', 'West Java', 'East Java', 'Bali'],
    'Brazil': ['São Paulo', 'Rio de Janeiro', 'Minas Gerais'],
    'Mexico': ['Jalisco', 'Nuevo León', 'Mexico City'],
    'Poland': ['Masovian', 'Lesser Poland', 'Greater Poland'],
    'Japan': ['Tokyo', 'Osaka', 'Kanagawa'],
  };
  const arr = pools[c];
  if (arr && arr.length) return arr[simpleHash(profile.email || 's') % arr.length];
  return c || 'California';
}

function deriveAddressLine1Fallback(profile) {
  const streets = ['Main', 'Oak', 'Maple', 'Cedar', 'Lake', 'Pine', 'Elm'];
  const suf = ['St', 'Rd', 'Ave', 'Blvd'];
  const n = 20 + (simpleHash(`${profile.email || ''}|a1`) % 9970);
  const st = streets[simpleHash(profile.city || 'c') % streets.length];
  const su = suf[simpleHash(profile.country || 'x') % suf.length];
  return `${n} ${st} ${su}`;
}

function matchSelectOptionLoose(selectEl, value) {
  if (!value || !selectEl || selectEl.tagName !== 'SELECT') return null;
  const v = String(value).toLowerCase().trim();
  if (!v) return null;
  const tokens = v.split(/\s+/).filter((t) => t.length > 1);
  for (const opt of selectEl.options) {
    const t = (opt.text || '').toLowerCase().trim();
    const val = (opt.value || '').toLowerCase().trim();
    if (t === v || val === v || t.replace(/\s+/g, '') === v.replace(/\s+/g, '')) return opt.value;
  }
  if (tokens.length) {
    for (const opt of selectEl.options) {
      const t = (opt.text || '').toLowerCase();
      const val = (opt.value || '').toLowerCase();
      if (tokens.every((tok) => t.includes(tok) || val.includes(tok))) return opt.value;
    }
  }
  for (const opt of selectEl.options) {
    const t = (opt.text || '').toLowerCase();
    const val = (opt.value || '').toLowerCase();
    if (t.includes(v) || val.includes(v)) return opt.value;
  }
  return null;
}

function pickSelectLocation(selectEl, primary, fallbacks) {
  const chain = [primary, ...(fallbacks || [])].filter(Boolean);
  for (const val of chain) {
    const m = matchSelectOption(selectEl, val);
    if (m) return m;
  }
  for (const val of chain) {
    const m = matchSelectOptionLoose(selectEl, val);
    if (m) return m;
  }
  return null;
}

function resolveLocationString(field, str, fallbacks) {
  if (str == null || str === '') return null;
  if (field.tagName === 'SELECT') return pickSelectLocation(field, str, fallbacks);
  return str;
}

function getLocationFieldValue(field, profile) {
  if (!profile) return null;
  const type = (field.type || '').toLowerCase();
  const name = (field.name || '').toLowerCase();
  const id = (field.id || '').toLowerCase();
  const placeholder = (field.placeholder || '').toLowerCase();
  const autocomplete = (field.autocomplete || '').toLowerCase().trim();
  const labelText = getLabelText(field).toLowerCase();
  const ariaLabel = (field.getAttribute('aria-label') || '').toLowerCase();
  const title = (field.getAttribute('title') || '').toLowerCase();
  const dataLabel = (field.getAttribute('data-label') || '').toLowerCase();
  const all = [name, id, placeholder, autocomplete, labelText, ariaLabel, title, dataLabel].join(' ');
  const L = profileLocationResolved(profile);

  if (/(latitude|longitude|\blat\b|\blng\b|\blon\b|coordinates?|geomap|geolocation|timezone|utc offset|ipv4|ipv6|wallet|ethereum|btc|contract\s+address|ip\s+address|what\s*3\s*words)/i.test(all)) {
    return null;
  }
  if (autocomplete && (/^(tel|cc-|phone|mobile|email|username|otp|one-time|current-password|new-password|bday|cc-number|cc-exp|cc-csc)/.test(autocomplete)
    || /\b(tel-country|tel-area|tel-national|transaction-currency)\b/.test(autocomplete))) {
    return null;
  }

  if (autocomplete) {
    if (autocomplete.includes('postal-code')) return resolveLocationString(field, L.postal, []);
    if (autocomplete.includes('street-address') || autocomplete.includes('address-line1')) return resolveLocationString(field, L.line1, [L.city]);
    if (autocomplete.includes('address-line2')) return resolveLocationString(field, L.line2, []);
    if (autocomplete.includes('address-level2')) return resolveLocationString(field, L.city, [profile.city]);
    if (autocomplete.includes('address-level1')) return resolveLocationString(field, L.state, [L.country, L.city]);
    if ((autocomplete === 'country' || autocomplete.includes('country-name')) && !autocomplete.includes('tel')) {
      return resolveLocationString(field, L.country, [L.state]);
    }
  }

  if (/\b(birth[\s_-]?(place|town|city)|place[\s_-]of[\s_-]birth|birthplace|born[\s_-]in|geburtsort|lieu[\s_-]de[\s_-]naissance|luogo[\s_-]di[\s_-]nascita|miejsce[\s_-]urodzenia|lugar[\s_-]de[\s_-]nacimiento)\b/i.test(all)) {
    return resolveLocationString(field, L.city, []);
  }

  if (/\b(nationality|citizenship|nacionalidad|nationalit(e|é)|staatsangeh(öo)rigkeit|citoyennet(e|é)|pa(íi)s[\s_-]de[\s_-]origen)\b/i.test(all)
    && !/\b(national[\s_-]?id|nid|ssn|sin|aadhaar|tax[\s_-]?id)\b/i.test(all)) {
    return resolveLocationString(field, L.country, []);
  }

  const streetRx = /(\b|^)(street( ?no| ?num(ber)?|name|line|_1)?|stra(ss|ß)e|strasse|straat|\bst\b\.?|address[\s_-]?(line)?[\s_-]?(1|one)?\b|addr(ess)?[\s_-]?(1|line[\s_-]?1)\b|addr1\b|addr_1\b|\badresse\b|\brue\b|\bvia\b(?!\s*lat)|\bcalle\b|direcci(ón|on)( fiscal| postal| de domicilio)?|domicilio|logradouro|correspondence[\s_-]address|residential[\s_-]address|mailing[\s_-]address|billing[\s_-]address|shipping[\s_-]address|(house|haus|huis|numero|n(º|o)\.?)[\s_-]?(no|num|number|de)?\b)/i;
  if (streetRx.test(all) && !/\b(email|ipv4|wallet|web_?url|company_?url|@)\b/i.test(all) && !/\bemail[\s_-]?address\b/i.test(all)) {
    const v = resolveLocationString(field, L.line1, [L.city]);
    if (v) return v;
  }

  if (/\b(apt|apartment|suite|unit|flat|door|dpto|depto|pi(ę|e)tro|étage|unidad)\b/i.test(all)
    && !/\b(floor[\s_-]plan|suite[\s_-]number[\s_-]of[\s_-]rooms)\b/i.test(all)) {
    const v = resolveLocationString(field, L.line2, []);
    if (v) return v;
  }

  const postalRx = /\b(postal|post[\s_-]?code|zip[\s_-]?code|\bzip\b|pincode|pin[\s_-]?code|eircode|postnr|postnummer|posta[\s_-]kod|zipcode|postleitzahl|cod(igo)?[\s_-]postal|c(óo)digo[\s_-]postal|\bplz\b|\bcap\b(?!\s*ital)|\bpsc\b|cep\b|kode[\s_-]pos|poskod|posta kodu)\b/i;
  if (postalRx.test(all)) {
    const v = resolveLocationString(field, L.postal, []);
    if (v) return v;
  }

  const stateRx = /\b(state|province|provincia|estado(?![\s_-]unido)|bundesland|oblast|wilayah|voivodeship|prefecture(?! of birth)|county\b|landkreis|\bkreis\b|canton|kanton|depart(amento|ment)|\bilçe\b|\bil\b(?=[\s_\-]|$)|region[\s_-]state|us[\s_-]state|federal[\s_-]state)\b/i;
  if (stateRx.test(all) && !/\b(city|ciudad|zip|postal)\b/i.test(name + id) && !/(company|employer)/i.test(all)) {
    const v = resolveLocationString(field, L.state, [L.country, L.city]);
    if (v) return v;
  }

  const cityRx = /\b(city|town|township|village|locality|municipality|commune|borough|suburb|settlement|metro(polis)?|post[\s_-]?town|place[\s_-]of[\s_-]residence|residence[\s_-]?city|current[\s_-]?city|home[\s_-]?city|living[\s_-]in|city[\s_-]?name|ciudad|localidad|poblaci(ón|on)|\bville\b|comune|citt(a|à)|stadt|wohnort|gemeente|woonplaats|lugar|miejscowo(śs|s)c|oras|kota|shahr|محل|市)\b/i;
  const bareLocationOk = /\blocation\b/i.test(all)
    && !/\b(allocation|relocation|geolocation|dislocation|collocation|elocation)\b/i.test(all)
    && !/\b(business|company|employer|job|work|office|server|ip|gps|map|browser|device|file|folder|url|storage|database|canonical|redirect)\s+location\b/i.test(all);
  if (L.city && (
    (cityRx.test(all) && !/(company|employer|organization|org[\s-]?name)/i.test(all))
    || /user\[[^\]]*(location|ciudad|city|ville|town|localid|place|wohn|resid|geo)\]/i.test(String(field.name))
    || /\b(hometown|home[\s_-]town|domicile|residency|where[\s_-]you[\s_-]live|your[\s_-]?location|forum[\s_-]location|profile[\s_-]location|member[\s_-]location)\b/i.test(all)
    || bareLocationOk
    || /\bcf[\s_-]?location\b|custom[\s_-]?field[^\s]*location|field[\s_-]?location\b/i.test(name + ' ' + id)
  )) {
    return resolveLocationString(field, L.city, []);
  }

  if (/\b(country|nation|pa(íi)s|pa(íi)ses|\bland\b|negara|ülke|country[\s_-]of[\s_-]residence)\b/i.test(all)
    && !/\b(city|ciudad|town|localid|municip(ality|i)|zip|postal|state|province)\b/i.test(all)) {
    const v = resolveLocationString(field, L.country, [L.state]);
    if (v) return v;
  }

  if (/\b(data|aws|sales|marketing|hosting|cdn|server|azure|gcp)\s*region\b/i.test(all)) {
    return null;
  }
  if (/\bregion\b/i.test(all) && !/\b(city|ciudad|municip(ality|i)?|regional(istic)?|city[\s-]?region|town|metro|cdn|aws|azure)\b/i.test(all)) {
    const v = resolveLocationString(field, L.state, [L.country, L.city]);
    if (v) return v;
  }

  if (/\bgeo[\s_-]?(city|town|place)|\bgeo_city\b/i.test(name + ' ' + id) && !/(allocation|relocation|dislocation|collocation)/i.test(name + id)) {
    return resolveLocationString(field, L.city, [L.country]);
  }
  if (/(^|[._[\-]])(profile|user|member|forum|signup|account|sfw)[_.-]?location\b|(^|_)location($|_|\d)|\bfield_(id_)?location\b/i.test(name + ' ' + id)
    && !/(allocation|relocation|dislocation|collocation|geolocation)/i.test(name + id)) {
    return resolveLocationString(field, L.city, [L.country]);
  }

  return null;
}

/** Label / aria / title is essentially just "Name" (many forms use empty or random input[name]). */
function looksLikeStandaloneNameCaption(s) {
  const t = String(s || '')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
  if (!t) return false;
  return /^(name|nombre|nom|naam)(\s*[*†:])?(\s*\(required\))?(\s*\(optional\))?(\s*required|\s*obligatorio)?$/.test(t);
}

// ── Field detection ───────────────────────────────────────────────────────────

function detectAndGetValue(field, profile) {
  const type        = (field.type || '').toLowerCase();
  const name        = (field.name || '').toLowerCase();
  const id          = (field.id || '').toLowerCase();
  const placeholder = (field.placeholder || '').toLowerCase();
  const autocomplete = (field.autocomplete || '').toLowerCase();
  const labelText   = getLabelText(field).toLowerCase();
  const ariaLabel   = (field.getAttribute('aria-label') || '').toLowerCase();
  const title         = (field.getAttribute('title') || '').toLowerCase();
  const dataLabel     = (field.getAttribute('data-label') || '').toLowerCase();

  const all = [name, id, placeholder, autocomplete, labelText, ariaLabel, title, dataLabel].join(' ');

  if (field.disabled) return null;
  // (Do not block readOnly: some UIs set it during loading; we still try when enabled on next pass.)

  // Honeypot (e.g. XenForo) — do not fill
  if (/(leave (this |the )?field|this field) blank|dej(ar|a)?( este)? campo( vac[íi]o)?|no rellen|honey|honeypot/.test(placeholder + ' ' + labelText + ' ' + name)) {
    return null;
  }
  if ((/email.*confirm|confirm.*email|verify[_-]email|website_url/.test(name) && /leave|blank|trampa/.test(placeholder + ' ' + labelText))) {
    return null;
  }

  // Skip non-fillable types
  if (['hidden','submit','button','file','image','reset'].includes(type)) return null;
  if (type === 'radio') return null;
  if (type === 'checkbox') {
    if (isTermsOrPolicyCheckbox(field, all, labelText)) {
      return true;
    }
    if (isHumanVerificationCheckbox(field, all, labelText)) {
      return true;
    }
    return null;
  }

  // Standard HTML autocomplete — works even when label is missing or non-English CMS uses random names
  if (autocomplete === 'given-name' && profile.firstName) return profile.firstName;
  if (autocomplete === 'family-name' && profile.lastName) return profile.lastName;
  if (autocomplete === 'name' && profile.fullName) return profile.fullName;

  // Date of birth: profile.dob* + selects / text / date
  if (field.tagName === 'SELECT' && isBirthdateSelectContext(field, all, labelText)) {
    const v = pickRandomBirthdaySelectValue(field, profile);
    if (v != null) return v;
  }
  if (isBirthdateDobInputContext(field, all, labelText) && (profile.dobIso || profile.birthYear != null)) {
    if (type === 'date' && profile.dobIso) return profile.dobIso;
    if (type === 'number' && isBirthdateYearInput(name, id, all, labelText)) {
      return String(profile.birthYear);
    }
    if (field.tagName === 'TEXTAREA' || (field.tagName === 'INPUT' && ['text', 'search', 'tel', 'url', 'number'].includes((type || 'text').toLowerCase()))) {
      const s = getDobTextValueForField(field, profile, all, labelText, placeholder, name, id);
      if (s != null) return s;
    }
  }

  // Password (forums: almost always <input type="password">, label may be "Contraseña")
  if (type === 'password') return profile.password;

  // Email (EN/ES) — "correo" on Spanish pages
  if (type === 'email') return profile.email;
  if (/e[\-_ ]?mail|correo( electr(ónico|onico|ito))?\b|user\[[^\]]*email\]|registr.*mail/i.test(all)) {
    if (type === 'search' || (type === 'text' && /^(q|s|kwp|keywords?|search)$/i.test(name) && /correo|mail|email|electr/i.test(all) === false)) {
      return null;
    }
    if (type === 'text' && (/\b(search|query|filter|busc(ador)?\b|company[_\s]url|search[_\s]q)/.test(name + ' ' + id) && /(correo|mail|email|electr|@)/.test(all) === false)) {
      return null;
    }
    return profile.email;
  }

  // First name
  if (/first[\s_\-]?name|fname|forename|given[\s_\-]?name/.test(all)) return profile.firstName;

  // Last name
  if (/last[\s_\-]?name|lname|surname|family[\s_\-]?name/.test(all)) return profile.lastName;

  // Usernames, forum nicks, XenForo (e.g. name="user[name]", label "Nick")
  {
    const Lab = (labelText + ' ' + placeholder + ' ' + ariaLabel);
    const xfname = String(field.name || '');
    if (/\buser\b|user[\s_\-]?name|user[_\s]?login|login[\s_\-]?name|handle|screen[\s_\-]?name|nombre( de| del)? usuario|nombre( a| del)? (mostrar|p(úu)blico|publico)|forum name/.test(all)
      || /user\[(name|user(name)?|nickname)\]/i.test(xfname)
      || (/\b(nick|nick[\s_\-]?name|apodo|nickname|pseud(onyme|onym|ónimo|onimo|onyme)?|usuari@|usuario)\b/.test(' ' + Lab + ' ' + name + ' ' + id) && !/(url|search|q\b|busc|empresa|company_)/.test(xfname + ' ' + id + Lab))
      || (/^name$/.test(name) && /\b(nick|p(úu)blico|pseud|apodo|obligator|mostrar)\b/.test(Lab) && !/company|brand_/.test(Lab))
    ) {
      return profile.username;
    }
  }

  // Display name
  if (/display[\s_\-]?name|public[\s_\-]?name/.test(all)) return profile.displayName;

  // Full name / author name
  if (/full[\s_\-]?name|your[\s_\-]?name|author[\s_\-]?name|comment[\s_\-]?author|first[\s_\-]?and[\s_\-]?last[\s_\-]?name|name[\s_\-]surname|real[\s_\-]?name|contact[\s_\-]?name/.test(all)) return profile.fullName;

  // Visible "Name" only (label / aria / title / data-label) — input name may be field_1, cf7*, etc.
  const textLikeNameField = field.tagName === 'TEXTAREA'
    || (field.tagName === 'INPUT' && (['text', 'search', 'tel'].includes(type) || type === ''));
  if (textLikeNameField) {
    const captionBits = [labelText, ariaLabel, title, dataLabel];
    if (captionBits.some(looksLikeStandaloneNameCaption)) {
      const neg = `${labelText} ${ariaLabel} ${placeholder} ${name} ${id}`;
      if (!/\b(nick|apodo|pseud|usuario|público|company|brand|business|middle|maiden|user\s*name)\b/i.test(neg)
        && !/user\[\s*(name|username|nickname)\s*\]/i.test(String(field.name || ''))
        && !/^user(name)?$/i.test(name) && !/^user(name)?$/i.test(id)) {
        return profile.fullName;
      }
    }
  }

  // generic name= only when it does not look like a forum "Nick"
  if (/^name$/.test(name) || /^name$/.test(id) || (type === 'text' && name === 'name' && !/\[/.test(String(field.name)))) {
    if (!/(nick|apodo|público|pseud|usuario|obligator|foro|message|messaging)/.test(labelText + ' ' + placeholder) && !/(user|email|q\b|s\b|search|company_)/.test(name + id + labelText)) {
      return profile.fullName;
    }
  }

  // Website / URL
  if (/web[\s_\-]?site|your[\s_\-]?url|home[\s_\-]?page|blog[\s_\-]?url|site[\s_\-]?url|\burl\b|\blink\b/.test(all)) return profile.website;

  {
    const loc = getLocationFieldValue(field, profile);
    if (loc != null) return loc;
  }

  // VMP / e-scooter model (mp365.es, etc.) — "Escribe el VMP"
  if (/\b(vmp|v\.?m\.?p\.?)\b|movilidad personal|veh(íi)culo(s)?( de )?movilidad|patinete( el(é|e)ctrico)?/i.test(all) || /vmp|m365|ninebot|patinete/i.test(placeholder + labelText + name)) {
    return (profile.vmp && String(profile.vmp).trim()) ? profile.vmp : 'M365 PRO';
  }

  return null;
}

function matchSelectOption(selectEl, value) {
  if (!value) return null;
  const lower = value.toLowerCase();
  for (const opt of selectEl.options) {
    if (opt.text.toLowerCase().includes(lower) || opt.value.toLowerCase().includes(lower)) {
      return opt.value;
    }
  }
  return null;
}

// ── Date of birth: random <select> (day / month / year) ─────────────────────

function getFormContextText(field) {
  const row = field.closest('tr, fieldset, .formRow, .inputGroup, [class*="formRow"], [class*="FormRow"], .form-group, .block-body, .pair, .pairs, dd, li, .ctrlUnit');
  if (row) return (row.innerText || '').slice(0, 1000);
  return '';
}

// On some UIs, only the month field matches first; day/year in the same row often
// have names like "day" / "year" / "dob_d" with no "dob" in regex line 1 — or stay disabled
// until month. If any sibling is dob_month, treat this select as DOB when name looks plausibly d/m/y.
function siblingDobContext(field) {
  if (field.tagName !== 'SELECT') return false;
  const nBad = (field.name || '') + (field.id || '');
  if (/(^|_)(country|nation|region|state|province|city|gender|title|location|p(aíi)s|phone|mobile)\b|^(q|s|kwp|search)$/i.test(nBad)) return false;
  const p = field.closest('tr, .formRow, .form-group, [class*="formRow"], [class*="FormRow"], [class*="inputGroup"], [class*="InputGroup"], .inputGroup, .input-group, .pairs, .pair, fieldset, li, .ctrlUnit, .control, dd, [class*="field"], [class*="Field"], .block-body, table, tbody, .ctrlWrapper');
  if (!p) return false;
  const sels = [...p.querySelectorAll('select')];
  if (sels.length < 2) return false;
  const hasDobMonth = sels.some((s) => {
    const n = ((s.name || '') + (s.id || '')).toLowerCase();
    return (/(^|_|\[)(dob|bday).*month|dob_month|bday\[_?1\]|bday\](\[|_)month|bday\[_?1\]_|_month(?!_)/.test(n) && /(dob|bday|birth|date|nac|geb|cumple)/.test(n))
      || /^dob_month$|dob\[month\]|bday\]\[1\]/.test(n);
  });
  if (!hasDobMonth) return false;
  if (!sels.includes(field)) return false;
  const n = ((field.name || '') + (field.id || '')).toLowerCase();
  if (/(dob|bday|birth|bdate|date|nac|geb|cumple|birt)(\[|_)(day|month|year|d|m|y|0|1|2)(\]|\b)/.test(n) || /dob_(d|m|y|day|month|year)\b/.test(n) || /bday\[_0\]|bday\[_1\]|bday\[_2\]|bday\[_?d\]|bday\[_?m\]|bday\[_?y\]/i.test(n)) return true;
  if (/(^|[^a-z])(dob|bday|birth|date|nac|geb|cumple)/.test(n) || /(day|month|year|mes|d(íi)a|a(ñn)o|anno|jj|_d|_m|_y|_dd|_mm|_yy|dd$|mm$|yy$|0\b|1\b|2\b|d$|m$|y$)/.test(n)) {
    if (sels.length >= 2 && sels.length <= 5) return true;
  }
  if (p.innerText && sels.length === 3 && sels.indexOf(field) < 3) {
    const t = p.innerText.slice(0, 500).toLowerCase();
    if (/(dob|birth|fecha|na(cim)?|cumple|bday|geb|naissance|date of birth|d\.\s*o\.\s*b)/.test(t) && n.length < 20) return true;
  }
  return false;
}

// Same form as dob_month, but day/year in another <tr> — not covered by siblingDobContext; use formScope in birthdateContextMatches
function formScopeDobContext(field) {
  if (field.tagName !== 'SELECT') return false;
  const nF = ((field.name || '') + (field.id || '')).toLowerCase();
  if (/(^|_)(country|nation|region|state|gender|kwp|search|phone|mobile|title|location|p(aíi)s)\b/.test(nF) && nF.length < 20 && !/(dob|bday|birth|d\[|day|year|0|1|2|_d|_y|bday0|bday2)/.test(nF)) {
    return false;
  }
  const root = field.closest('form') || field.closest('[class*="register"]') || field.closest('[class*="Register"]') || field.closest('[class*="signup"]') || field.closest('[id*="register"]') || field.closest('main') || field.closest('[role="main"]');
  if (!root || !root.querySelectorAll) return false;
  const sels = [...root.querySelectorAll('select')];
  if (sels.length < 2) return false;
  const hasDobMonth = sels.some((s) => {
    const n = ((s.name || '') + (s.id || '')).toLowerCase();
    return n.indexOf('dob_month') >= 0 || /dob\[(m|month)\]|^dob_month$|bday\[_1\]|bday\]\[1\]|dob\[_1\]|bday\]\[month\]|bday\[1\]/.test(n) || n.includes('bday[month]') || n.includes('bday[1]');
  });
  if (!hasDobMonth || !sels.includes(field)) return false;
  if (/(^|_)(dob|bday).{0,16}(month|_m|mes|1)(\[|$|_)|^dob_month$|_month$|bday1\b|bday\[_1\]$|dob\[_1\].*m|bday1|dob_m\b/.test(nF) && /(month|mes|dob_m|bday1)/.test(nF)) {
    return false;
  }
  if (nF.indexOf('dob_day') >= 0 || nF.indexOf('dob_year') >= 0 || nF.indexOf('d[day]') >= 0 || nF.indexOf('d[year]') >= 0) {
    return true;
  }
  if (/(dob|bday|birt).*(d(ay|ía)|año|e(ar)?y|0|2|_d$|_y$|_day|_year)|bday0|bday2|bday\[(0|2|day|year|d|y)\]|dob\[(0|2|day|year|d|y)\]/.test(nF)) {
    return true;
  }
  if (nF === 'bday0' || nF === 'bday2' || nF === 'bday[0]' || nF === 'bday[2]') {
    return true;
  }
  return false;
}

const HYBRID_DOB_P =
  'tr, .formRow, .form-group, [class*="formRow"], [class*="FormRow"], [class*="inputGroup"], [class*="InputGroup"], .inputGroup, .input-group, .pairs, .pair, fieldset, li, .ctrlUnit, .block-body, dd, [class*="field"], [class*="Field"]';

function hasDobMonthInSelectName(sel) {
  const n = ((sel.name || '') + (sel.id || '')).toLowerCase();
  if (/(^|_)(country|nation|state|region|title|gender)\b|^(q|s|kwp|search)$/.test(n) && n.length < 20) {
    if (!/(dob|bday|birth|month|mes)/.test(n)) return false;
  }
  return (/(^|_|\[)(dob|bday).*month|dob_month|bday\[_?1\]|bday\](\[|_)month|bday\[_?1\]_|_month(?!_)/.test(n) && /(dob|bday|birth|date|nac|geb|cumple)/.test(n))
    || /^dob_month$|dob\[month\]|bday\]\[1\]\s*$|bday\[1\]\s*$/i.test(n.trim());
}

function countMonthNameLikeOptions(usable) {
  let c = 0;
  for (const o of usable) {
    const t = ((o.text || '') + ' ' + (o.value || '') + ' ' + (o.getAttribute('label') || '')).toLowerCase();
    if (/(jan(uary|uar)?|feb(ru|uary)?|m(ä|a)r?z?|apr(il)?|may|juni?|juli?|aug(ust)?|sep(ember|t)?|okt|oct(ober)?|nov(ember)?|dec(ember)?|dez(ember)?|diciembre|enero|febr|märz?|mese|mes( )?\d|month|monat|mois|september|november|december|february|january|august|sept\.?)/.test(t)) c++;
  }
  return c;
}

function optionsTextLooksLikeMonthList(usable) {
  if (usable.length < 3) return false;
  const c = countMonthNameLikeOptions(usable);
  return c >= 3 && c >= Math.max(2, Math.floor(usable.length * 0.15)) && usable.length <= 28;
}

function isLikelyDobMonthSelect(el) {
  if (!el || el.tagName !== 'SELECT' || el.disabled) return false;
  if (hasDobMonthInSelectName(el)) return true;
  const u = getUsableBirthdateOptions(el);
  if (u.length < 3) return false;
  if (optionsTextLooksLikeMonthList(u)) return true;
  if (u.length < 4) return false;
  return inferBirthSelectKindFromOptions(u) === 'month';
}

function isFillableDobishTextInput(el) {
  if (el.tagName === 'TEXTAREA') return !el.disabled;
  if (el.tagName !== 'INPUT' || el.disabled) return false;
  const t = (el.type || 'text').toLowerCase();
  if (!['text', 'search', 'tel', 'url', 'number'].includes(t)) return false;
  const pl = (el.getAttribute('placeholder') || '').toLowerCase().replace(/\s+/g, ' ').trim();
  if (pl === 'day' || pl === 'year' || pl === 'dd' || pl === 'yyyy' || pl === 'yy' || /^(día|dia|gün|tag|año|anno|aaaa|jjjj|jour|d)$/.test(pl)) return true;
  const n = ((el.name || '') + (el.id || '')).toLowerCase();
  if (/(^|_)(q|s|kwp|search|email|e_mail|user(name)?|login|phone|url|captcha|keyword)\b|honeypot/i.test(n) && !/(dob|bday|birth|bdate|date_of_birth|d\.o\.b|fnac|geb)/.test(n)) return false;
  if (/\b(username|user_name|user-name|userlogin|usrname)\b/.test(n) && !/(dob|bday|birth|bdate|date_of_birth|d\.o\.b|fnac|geb)/.test(n)) return false;
  return true;
}

// Find a small wrapper: exactly one month <select> and 1–3 text fields (common MUI / plain <div> rows have no .formRow).
function findHybridDobGroupHost(field) {
  if (field.disabled) return null;
  if (field.tagName === 'SELECT') {
    if (field.style && field.style.display === 'none') return null;
  } else if (field.tagName === 'INPUT' || field.tagName === 'TEXTAREA') {
    if (!isFillableDobishTextInput(field)) return null;
  } else {
    return null;
  }

  const tryHost = (p) => {
    if (!p || p === document.body || p === document.documentElement) return null;
    const sels = [...p.querySelectorAll('select')].filter((s) => !s.disabled);
    if (sels.length !== 1) return null;
    if (!isLikelyDobMonthSelect(sels[0])) return null;
    const textInputs = [...p.querySelectorAll('input, textarea')].filter(isFillableDobishTextInput);
    if (textInputs.length < 1 || textInputs.length > 3) return null;
    if (sels[0] === field || textInputs.includes(field)) return p;
    return null;
  };

  const fromSemantic = tryHost(field.closest(HYBRID_DOB_P));
  if (fromSemantic) return fromSemantic;

  let el = field.parentElement;
  for (let d = 0; d < 10 && el; d++, el = el.parentElement) {
    if (el.tagName === 'BODY' || el.tagName === 'HTML') break;
    const hit = tryHost(el);
    if (hit) return hit;
    if (el.tagName === 'FORM') break;
  }
  return null;
}

// Month <select> + day/year <input> in the same group (siblingDobContext needs 2+ selects, so that path misses this).
function hybridBirthdateRowContext(field) {
  return findHybridDobGroupHost(field) != null;
}

function formRootForDobHeuristic(field) {
  return field.closest('form') || field.closest('[class*="register"]') || field.closest('[class*="Register"]') || field.closest('[class*="signup"]') || field.closest('[id*="register"]') || field.closest('main') || field.closest('[role="main"]');
}

// Day/year <input> in a different row than the month <select>, but in the same form; names/placeholders still hint.
function formScopeHybridDobTextContext(field) {
  if (field.tagName !== 'INPUT' && field.tagName !== 'TEXTAREA') return false;
  if (field.disabled || !isFillableDobishTextInput(field)) return false;
  if (hybridBirthdateRowContext(field)) return false;
  const root = formRootForDobHeuristic(field);
  if (!root) return false;
  const sels = [...root.querySelectorAll('select')].filter((s) => !s.disabled);
  if (!sels.length) return false;
  const hasMonth = sels.some((s) => isLikelyDobMonthSelect(s) || hasDobMonthInSelectName(s));
  if (!hasMonth) return false;
  if (field.tagName === 'SELECT' || sels.includes(field)) return false;

  const n = ((field.name || '') + ' ' + (field.id || '')).toLowerCase();
  const ph = (field.placeholder || '').toLowerCase().replace(/\s+/g, ' ').trim();
  if (/(^|_|\[)(bday|dob|date_of_birth|birth( ?date|_?year|_?month|_?day)?|bdate|fecnac|fecha_?nac|na(cim)?)/.test(n)
    || /(bday|dob)\[?(day|month|year|d|m|y|0|1|2)\]?\b/.test(n) || /dob[_-](d|m|y|day|month|year)\b/.test(n)) {
    return true;
  }
  if (ph === 'day' || ph === 'dd' || /^(día|dia|gün|tag|jj|d)$/.test(ph)) return true;
  if (ph === 'year' || ph === 'yyyy' || ph === 'yy' || /^(año|anno|jahr|a(aaa)?a?)$/.test(ph)) return true;
  if (sels.some((s) => hasDobMonthInSelectName(s))) {
    if (/(bday0|bday\[_0\]|dob_?d|dob_?day|bday\[_?d\]|_day$|_d$|d\[_0\])/.test(n) && n.length < 64) return true;
    if (/(bday2|bday\[_2\]|dob_?y|dob_?year|bday\[_?y\]|_year$|_y$|d\[_2\])/.test(n) && n.length < 64) return true;
  }
  return false;
}

function nodeDocumentOrder(a, b) {
  if (a === b) return 0;
  if (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
  if (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_PRECEDING) return 1;
  return 0;
}

function isDobishText(s) {
  return /(dob|bday|birth|date\s*of\s*birth|d[.\s/]*o[.\s/]*b|fecnac|na(cim|cimiento)?|geb|cumple)/i.test(String(s || ''));
}

function isIdentityFieldForDobFallback(name, id, placeholder, labelText, ariaLabel) {
  const s = [name, id, placeholder, labelText, ariaLabel].join(' ').toLowerCase();
  if (isDobishText(s)) return false;
  return /\b(username|user_name|user-name|user[\s._-]+name|user(name)?|login|nick(name)?|display\s*name|full\s*name|first\s*name|last\s*name|surname|forename|email|e[-_\s]?mail|phone|mobile|company|website|url|city|country|state|province|postal|zip|address|street|location|search|query)\b/.test(s);
}

function isLikelyHybridDobNumericInput(el) {
  if (!el || el.disabled) return false;
  const t = (el.type || 'text').toLowerCase();
  const ml = parseInt(el.getAttribute('maxlength') || '', 10);
  const pattern = (el.getAttribute('pattern') || '').toLowerCase();
  const pl = (el.getAttribute('placeholder') || '').toLowerCase();
  const lbl = (getLabelText(el) || '').toLowerCase();
  const nm = ((el.name || '') + ' ' + (el.id || '')).toLowerCase();
  const looksDayYear = /\b(day|dd|year|yyyy|yy|d(í|i)a|a(ñ|n)o|jahr)\b/.test(pl + ' ' + lbl + ' ' + nm);
  if (looksDayYear) return true;
  if (t === 'number') return true;
  if (!isNaN(ml) && ml > 0 && ml <= 4) return true;
  if (/\\d|\[0-9\]/.test(pattern)) return true;
  if (isDobishText(nm) && (/_d\b|_y\b|\[0\]|\[2\]|day|year/.test(nm))) return true;
  return false;
}

function getHybridDobTextPartForField(field, all, labelText, placeholder) {
  if (field.tagName === 'SELECT') return null;
  if (!formScopeHybridDobTextContext(field) && !hybridBirthdateRowContext(field)) return null;

  if (formScopeHybridDobTextContext(field) && !hybridBirthdateRowContext(field)) {
    const n0 = ((field.name || '') + (field.id || '')).toLowerCase();
    const ph = (String(placeholder) || '').toLowerCase().replace(/\s+/g, ' ').trim();
    if (n0.includes('bday[day]') || n0.includes('bday[0]') || n0.includes('bday_day') || /dob[_-]d(ay)?\b/.test(n0) || n0.includes('bday_d') || /bday[_-]?0\b|bd[_-]?0\b/.test(n0)) return 'd';
    if (n0.includes('bday[year]') || n0.includes('bday[2]') || n0.includes('bday_year') || /dob[_-]y(ear)?\b/.test(n0) || n0.includes('bday_y') || /bday[_-]?2\b|bd[_-]?2\b/.test(n0) || isBirthdateYearInput(field.name || '', field.id || '', all, labelText)) return 'y';
    if (n0.includes('bday[month]') || n0.includes('bday[1]') || n0.includes('bday_month') || /dob[_-]m(onth)?\b/.test(n0) || n0.includes('bday_m') || /bday[_-]?1\b|bd[_-]?1\b/.test(n0)) return 'm';
    if (ph === 'day' || ph === 'dd' || /^(día|dia|gün|tag|d)$/.test(ph)) return 'd';
    if (ph === 'year' || ph === 'yyyy' || ph === 'yy' || /^(año|anno|jahr|aaaa)$/.test(ph)) return 'y';
    return null;
  }

  const p = findHybridDobGroupHost(field) || field.closest(HYBRID_DOB_P);
  if (!p) return null;
  const theSel = [...p.querySelectorAll('select')].find((s) => !s.disabled);
  if (!theSel || !isLikelyDobMonthSelect(theSel)) return null;
  const textInputs = [...p.querySelectorAll('input, textarea')].filter(isFillableDobishTextInput);
  if (!textInputs.includes(field)) return null;

  const n0 = ((field.name || '') + (field.id || '')).toLowerCase();
  const pl = (String(placeholder) || '').toLowerCase().replace(/\s+/g, ' ').trim();
  if (n0.includes('bday[day]') || n0.includes('bday[0]') || n0.includes('bday_day') || /dob[_-]d(ay)?\b/.test(n0) || n0.includes('bday_d') || /bday[_-]?0\b|bd[_-]?0\b/.test(n0)) return 'd';
  if (n0.includes('bday[year]') || n0.includes('bday[2]') || n0.includes('bday_year') || /dob[_-]y(ear)?\b/.test(n0) || n0.includes('bday_y') || /bday[_-]?2\b|bd[_-]?2\b/.test(n0) || isBirthdateYearInput(field.name || '', field.id || '', all, labelText)) return 'y';
  if (n0.includes('bday[month]') || n0.includes('bday[1]') || n0.includes('bday_month') || /dob[_-]m(onth)?\b/.test(n0) || n0.includes('bday_m') || /bday[_-]?1\b|bd[_-]?1\b/.test(n0)) return 'm';

  if (pl === 'day' || pl === 'dd' || /^(día|dia|gün|tag|d)$/.test(pl)) return 'd';
  if (pl === 'year' || pl === 'yyyy' || pl === 'yy' || /^(año|anno|jahr|aaaa)$/.test(pl)) return 'y';
  if (pl === 'month' || pl === 'mm' || pl === 'mes' || pl === 'mois') return 'm';

  const lbf = (getLabelText(field) || '').toLowerCase();
  if (/\bday\b|(^|[^a-z])(d(íi|i)a|jour|tag|jj)\b/i.test(lbf) && !/\b(year|a(ñn)o|anno|jahr|yyyy)\b|mes|month|mois/i.test(lbf)) return 'd';
  if (/\b(year|año|anno|jahr|yyyy)\b/i.test(lbf) && !/\bday\b|d(íi|i)a|jour|mes|month|mois/i.test(lbf)) return 'y';
  if (/(mes|month|monat|mois)\b/.test(lbf) && !/\bday\b|\b(year|año|anno)\b|yyyy/i.test(lbf)) return 'm';

  if (textInputs.length === 1) {
    if (isBirthdateYearInput(field.name || '', field.id || '', all, labelText)) return 'y';
    return 'd';
  }
  if (textInputs.length >= 2) {
    const candidates = textInputs.filter(isLikelyHybridDobNumericInput);
    if (candidates.length >= 2 && candidates.includes(field)) {
      const tOrd = candidates.slice().sort(nodeDocumentOrder);
      if (tOrd[0] === field) return 'd';
      if (tOrd[1] === field) return 'y';
    }
  }
  return null;
}

function fillHybridDobGaps(profile) {
  const dob = getDobFromProfile(profile);
  if (!dob) return 0;
  let filled = 0;
  const doneHosts = new Set();
  const allFields = [...document.querySelectorAll('input, textarea, select')];

  for (const field of allFields) {
    const host = findHybridDobGroupHost(field);
    if (!host || doneHosts.has(host)) continue;
    doneHosts.add(host);

    const sel = [...host.querySelectorAll('select')].find((s) => !s.disabled && isLikelyDobMonthSelect(s));
    if (!sel) continue;
    const textInputs = [...host.querySelectorAll('input, textarea')].filter((el) => !el.disabled && isFillableDobishTextInput(el));
    if (!textInputs.length) continue;

    for (const inp of textInputs) {
      const cur = String(inp.value || '').trim();
      if (cur) continue;
      const t = (inp.type || 'text').toLowerCase();
      if (!['text', 'search', 'tel', 'url', 'number'].includes(t) && inp.tagName !== 'TEXTAREA') continue;

      const name = (inp.name || '').toLowerCase();
      const id = (inp.id || '').toLowerCase();
      const placeholder = (inp.placeholder || '').toLowerCase();
      const labelText = (getLabelText(inp) || '').toLowerCase();
      const ariaLabel = (inp.getAttribute('aria-label') || '').toLowerCase();
      if (isIdentityFieldForDobFallback(name, id, placeholder, labelText, ariaLabel)) continue;
      const all = [name, id, placeholder, (inp.autocomplete || '').toLowerCase(), labelText, ariaLabel].join(' ');

      let part = getHybridDobTextPartForField(inp, all, labelText, placeholder);
      if (!part) {
        const candidates = textInputs
          .filter((el) => !String(el.value || '').trim())
          .filter((el) => {
            const n = (el.name || '').toLowerCase();
            const i = (el.id || '').toLowerCase();
            const p = (el.placeholder || '').toLowerCase();
            const l = (getLabelText(el) || '').toLowerCase();
            const a = (el.getAttribute('aria-label') || '').toLowerCase();
            return !isIdentityFieldForDobFallback(n, i, p, l, a) && isLikelyHybridDobNumericInput(el);
          });
        if (candidates.length >= 2 && candidates.includes(inp)) {
          const ord = candidates.slice().sort(nodeDocumentOrder);
          if (ord[0] === inp) part = 'd';
          else if (ord[1] === inp) part = 'y';
        }
      }
      if (!part) continue;

      if (part === 'd') {
        setNativeValue(inp, String(dob.d));
        filled++;
      } else if (part === 'y') {
        setNativeValue(inp, String(dob.y));
        filled++;
      } else if (part === 'm') {
        setNativeValue(inp, String(dob.m));
        filled++;
      }
    }
  }
  return filled;
}

/** Username / login fields must never be classified as DOB (row text can mention "birth" nearby). */
function isUsernameFieldContext(field, all, labelText) {
  const ac = (field.getAttribute('autocomplete') || '').toLowerCase();
  if (ac === 'username' || ac === 'nickname') return true;
  const name = String(field.name || '');
  const id = String(field.id || '');
  const ph = String(field.placeholder || '').toLowerCase();
  const al = String(field.getAttribute('aria-label') || '').toLowerCase();
  const tl = String(labelText || '').toLowerCase();
  const bundle = `${name} ${id} ${all} ${tl} ${ph} ${al}`.toLowerCase();
  if (/\b(username|user_name|user-name|userlogin|usrname)\b/.test(bundle)) return true;
  if (/\buser[\s._-]+name\b/.test(bundle)) return true;
  if (/user\[\s*(name|username|nickname)\s*\]/i.test(name)) return true;
  return false;
}

function birthdateContextMatches(field, all, labelText) {
  if (field.disabled) return false;
  if (isUsernameFieldContext(field, all, labelText)) return false;
  const ac = (field.getAttribute('autocomplete') || '').toLowerCase();
  if (ac && (ac === 'bday' || ac.startsWith('bday-') || ac === 'bday-day' || ac === 'bday-month' || ac === 'bday-year' || ac === 'bday-full')) return true;
  const n = ((field.name || '') + ' ' + (field.id || ''));
  const rowT = getFormContextText(field);
  const block = (n + ' ' + all + ' ' + labelText + ' ' + rowT).toLowerCase();
  const nLow = n.toLowerCase();
  if (/(^|_|\[)(bday|dob|date_of_birth|dateofbirth|birth( ?date|_?year|_?month|_?day)?|bdate|fecnac|fecha_?nac|bday\]|birth_?day|na(cim|cimiento)_)/.test(nLow) ||
    /(user\[[^\]]*birth|custom_?field[^\]]*birth|cf\[.*\bbirth)/.test(nLow) ||
    /bday(\[|_)(day|month|year|d|m|y|0|1|2)(\]|\b)/.test(nLow) ||
    /dob[_-](d|m|y|day|month|year)\b/.test(nLow)) {
    return true;
  }
  if (/(date of birth|d[.\s/]*o[.\s/]*b|d\/o\/b|birth( ?date|day)?\b|dob\b|birthdate|b\.?d|fecha( de)? nac|cumplea(ñn)os|fecnac|geburtsdat|date de naissance|naissance|born on)/.test(block) &&
    !(/(spouse|parent|child|another|employ).{0,50}(dob|birth|nac|naissance)/.test(block))) {
    return true;
  }
  if (/(bday|dob|birth|nac|cumple|geb|born|naissance)/.test(nLow) && (/\[day\]|(month|mes)|\[year\]|(a(ñn)o|jahr|yyyy)/.test(nLow + labelText) || /bday\[/.test(nLow))) {
    return true;
  }
  if (siblingDobContext(field)) return true;
  if (formScopeDobContext(field)) return true;
  if (hybridBirthdateRowContext(field) || formScopeHybridDobTextContext(field)) return true;
  return false;
}

function isBirthdateSelectContext(field, all, labelText) {
  if (field.tagName !== 'SELECT') return false;
  return birthdateContextMatches(field, all, labelText);
}

function isBirthdateDobInputContext(field, all, labelText) {
  if (field.tagName !== 'INPUT' && field.tagName !== 'TEXTAREA') return false;
  if (['hidden', 'submit', 'button', 'file', 'image', 'reset', 'checkbox', 'radio', 'password', 'email'].includes((field.type || '').toLowerCase())) return false;
  return birthdateContextMatches(field, all, labelText);
}

function isBirthdateYearInput(name, id, all, labelText) {
  const a = (name + ' ' + id + ' ' + labelText + ' ' + all).toLowerCase();
  if (/(day|d(íi|i)a|mes|month|jour|tag|dd\b|_d\b|bday\[_?0\]|bday\[_?d)/.test(a) && /(dob|birth|bday|fecnac|na(cim)?|geb|cumple)/.test(a)) return false;
  if (/(year|a(ñn)o|anno|jahr|yy\b|yyyy|birth_?y|bday\[_?2\]|bday\[_?y\]|dob_?y|_byear|reg_?y\b)/.test(a) && /(dob|birth|bday|fecnac|na(cim)?|geb|cumple|date of birth)/.test(a)) return true;
  return /(dob_?y|birth_?year|bday\[_?y|bday\[_?2|reg_?year|year_?of_?birth|a(ñn)o( de)? nac)/.test(a);
}

function getDobFromProfile(profile) {
  if (!profile) return null;
  if (profile.dobIso && /^\d{4}-\d{2}-\d{2}/.test(String(profile.dobIso))) {
    const [Y, M, D] = profile.dobIso.split(/[-T]/)[0].split('-').map(Number);
    if (!isNaN(Y) && !isNaN(M) && !isNaN(D)) return { y: Y, m: M, d: D };
  }
  if (profile.birthYear != null && profile.birthMonth != null && profile.birthDay != null) {
    return { y: profile.birthYear, m: profile.birthMonth, d: profile.birthDay };
  }
  return null;
}

const MONTH_3 = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

function optionMatchesMonthValue(opt, month) {
  const t = (opt.text || '').toLowerCase();
  if (MONTH_3[month - 1] && t.includes(MONTH_3[month - 1])) return true;
  if (month === 1 && t.includes('ene')) return true;
  if (month === 2 && t.includes('feb')) return true;
  if (month === 3 && (t.includes('mär') || t.includes('mar'))) return true;
  if (month === 4 && t.includes('abr')) return true;
  if (month === 5 && t.includes('may')) return true;
  if (month === 6 && t.includes('jun')) return true;
  if (month === 7 && t.includes('jul')) return true;
  if (month === 8 && t.includes('ago')) return true;
  if (month === 9 && (t.includes('sep') || t.includes('sept'))) return true;
  if (month === 10 && t.includes('oct')) return true;
  if (month === 11 && t.includes('nov')) return true;
  if (month === 12 && (t.includes('dec') || t.includes('dic') || /d(e|é)c/.test(t))) return true;
  const n = optionNumericHint(opt);
  if (!isNaN(n) && n === month) return true;
  if (!isNaN(n) && n >= 0 && n < 12 && n + 1 === month) return true;
  return false;
}

function tryMatchProfileToBirthdaySelect(field, profile) {
  const dob = getDobFromProfile(profile);
  if (!dob) return null;
  const usable = getUsableBirthdateOptions(field);
  if (usable.length === 0) return null;
  const part = classifyBirthdateSelectPart(field) ?? inferBirthSelectKindFromOptions(usable);
  if (!part) return null;
  if (part === 'year') {
    for (const o of usable) {
      if (getOptionAsYearNumber(o) === dob.y) return o.value;
    }
    return null;
  }
  if (part === 'day') {
    for (const o of usable) {
      const d0 = optionNumericHint(o);
      if (!isNaN(d0) && d0 === dob.d) return o.value;
    }
    return null;
  }
  if (part === 'month') {
    for (const o of usable) {
      if (optionMatchesMonthValue(o, dob.m)) return o.value;
    }
    return null;
  }
  return null;
}

function getDobTextValueForField(field, profile, all, labelText, placeholder, name, id) {
  const dob = getDobFromProfile(profile);
  if (!dob) return null;
  const n = (name + ' ' + id).toLowerCase();
  if (n.includes('bday[day]') || n.includes('bday[0]') || n.includes('bday_day') || /dob[_-]d(ay)?\b/.test(n) || n.includes('bday_d') || /bday[_-]?0\b|bd[_-]?0\b/.test(n)) {
    return String(dob.d);
  }
  if (n.includes('bday[month]') || n.includes('bday[1]') || n.includes('bday_month') || /dob[_-]m(onth)?\b/.test(n) || n.includes('bday_m') || /bday[_-]?1\b|bd[_-]?1\b/.test(n)) {
    return String(dob.m);
  }
  if (n.includes('bday[year]') || n.includes('bday[2]') || n.includes('bday_year') || /dob[_-]y(ear)?\b/.test(n) || n.includes('bday_y') || /bday[_-]?2\b|bd[_-]?2\b/.test(n) || isBirthdateYearInput(name, id, all, labelText)) {
    return String(dob.y);
  }
  const hyP = getHybridDobTextPartForField(field, all, labelText, placeholder);
  if (hyP === 'd') return String(dob.d);
  if (hyP === 'm') return String(dob.m);
  if (hyP === 'y') return String(dob.y);
  const p = (placeholder + ' ' + (field.className || '') + ' ' + (field.getAttribute('data-date-format') || '') + ' ' + (field.getAttribute('pattern') || '')).toLowerCase();
  const a = (name + ' ' + id + ' ' + all).toLowerCase();
  if (/mm[\/\.\-\s]*dd[\/\.\-\s]*yy(?!y)|\bmdy|american|us-?date|@mdy|mm\/dd|month.?(first|before).?day|usa|format.?(us|american)/.test(p + a)) return profile.dobUs;
  if (/dd[\/\.\-]\s*mm[\/\.\-]\s*yy(?!y)|\bdmy|\bd\/?m\/?y\b|d\.m\.(y{2,4})|d\.?m\.?y|day.?(first|before).?month|uk( date)?|europ|dutch|french( date)?|german( date)?|de-?at|d\.-m\.-y|ddmmyy|d\/m\/(20)?y|tt\.\s*mm|jj\.|dd\.|ddmm/.test(p + a)) {
    return profile.dobDe || profile.dobEu;
  }
  if (/yy[\s\/.-]mm|yyyy[\s\/.-]m|iso|y-m-d|year[\s-]+m|ymd|^\s*yyyy/i.test(p) || a.includes('dob-iso') || a.includes('data-iso')) return profile.dobIso;
  if (/mmdd|m\/d\/(20)/.test(placeholder) || a.includes('format-md')) return profile.dobUs;
  return profile.dobIso;
}

function getUsableBirthdateOptions(field) {
  return [...field.options].filter((opt, i) => {
    if (opt.disabled) return false;
    const t = (opt.text || '').trim();
    const v = String(opt.value ?? '');
    if (i === 0 && v === '' && t.length < 2) return false;
    if (v === '' && /^(—|-|\.{2,}|\?|#+|choose|select|selecc|día|dia|day|mes|mois|a(ñn)o|year|month|pick)$/i.test(t)) return false;
    return true;
  });
}

function optionNumericHint(opt) {
  // Prefer the whole value when it's numeric (e.g. "15", "15 — Monday") so day selects work
  const rawV = (opt.getAttribute('value') != null ? opt.getAttribute('value') : (opt.value || '')).trim();
  if (/^\-?\d{1,4}$/.test(rawV)) {
    return parseFloat(rawV);
  }
  const t = (opt.value || ' ') + (opt.text || ' ');
  const m = t.match(/-?[\d.]+/);
  if (m) {
    const n = parseFloat(m[0]);
    if (!isNaN(n)) return n;
  }
  const low = (opt.text || '').toLowerCase();
  const i = low.search(/\d{1,4}/);
  if (i >= 0) {
    const mm = low.slice(i).match(/[\d.]+/);
    if (mm) return parseFloat(mm[0]);
  }
  return NaN;
}

// Year from option: value is often 0,1,2…; real year is usually in option *text* (e.g. "2002")
function getOptionAsYearNumber(opt) {
  const blob = ((opt.text || '') + ' ' + (opt.getAttribute('value') || '') + ' ' + (opt.value || ''));
  for (const s of blob.match(/\b\d{4}\b/g) || []) {
    const y = parseInt(s, 10);
    if (y >= 1800 && y <= 2200) return y;
  }
  const h = optionNumericHint(opt);
  if (!isNaN(h) && h === Math.floor(h) && h >= 1900) return h;
  return NaN;
}

function inferBirthSelectKindFromOptions(usable) {
  if (usable.length < 1) return null;
  const nowY = new Date().getFullYear();
  const yParsed = usable.map((o) => getOptionAsYearNumber(o)).filter((n) => !isNaN(n) && n >= 1900);
  if (yParsed.length >= Math.max(1, Math.floor(usable.length * 0.35)) && (new Set(yParsed).size >= 2 || (Math.min(...yParsed) < 2010 && Math.max(...yParsed) > 1920))) {
    return 'year';
  }
  const nums = usable.map(optionNumericHint);
  const finite = nums.filter((n) => !isNaN(n) && n >= 0);
  if (usable.length >= 3 && optionsTextLooksLikeMonthList(usable) && (finite.length < Math.max(1, Math.floor(usable.length * 0.35)) || (finite.length > 0 && Math.min(...finite) >= 1 && Math.max(...finite) <= 12))) {
    return 'month';
  }
  if (finite.length < Math.max(1, Math.floor(usable.length * 0.35))) return null;
  const min = Math.min(...finite);
  const max = Math.max(...finite);
  if (min >= 1900 && max <= 2040 && usable.length >= 3) return 'year';
  if (min >= 1 && max <= 31 && max > 12) return 'day';
  if (min >= 1 && max <= 12 && (usable.length <= 20 || (max - min) <= 11)) return 'month';
  if (min >= 0 && max <= 12 && min < 1 && max >= 1 && usable.length >= 4) return 'month';
  return null;
}

function classifyBirthdateSelectPart(field) {
  const ac = (field.getAttribute('autocomplete') || '').toLowerCase();
  if (ac === 'bday-day') return 'day';
  if (ac === 'bday-month') return 'month';
  if (ac === 'bday-year') return 'year';
  if (ac === 'bday' || ac === 'bday-full') return null;

  const n = ((field.name || '') + ' ' + (field.id || '')).toLowerCase();
  const labelOnly = (getLabelText(field) || '').toLowerCase();
  const rowForBirth = (getFormContextText(field) + ' ' + labelOnly + ' ' + n).toLowerCase();
  const birthCtx = /(birth|dob|bday|nac|geb|cumple|fecnac|geburtsd|date of birth|d\.?\s*o\.?\s*b|fecha( de)? nac)/.test(rowForBirth);

  if (n.includes('bday[day]') || n.includes('bday[0]') || n.includes('bday_day') || /dob[_-]d(ay)?\b/.test(n) || n.includes('bday_d') || /bday[_-]?0\b|bd[_-]?0\b/.test(n)) return 'day';
  if (n.includes('bday[month]') || n.includes('bday[1]') || n.includes('bday_month') || /dob[_-]m(onth)?\b/.test(n) || n.includes('bday_m') || /bday[_-]?1\b|bd[_-]?1\b/.test(n)) return 'month';
  if (n.includes('bday[year]') || n.includes('bday[2]') || n.includes('bday_year') || /dob[_-]y(ear)?\b/.test(n) || n.includes('bday_y') || /bday[_-]?2\b|bd[_-]?2\b/.test(n) || /birth_?y|year_?of|_yyyy\b|byear|sel_?y\b|sel_?year\b|reg_?y\b|reg_?year\b|dob_?y\b|dob_?yr\b/.test(n)) return 'year';

  if (/\[day\]/i.test(n) && /(bday|dob|birth|bdate|fec|na(cim)?)/.test(n)) return 'day';
  if (/\[month\]/i.test(n) && /(bday|dob|birth|bdate|fec|na(cim)?)/.test(n)) return 'month';
  if (/\[year\]/i.test(n) && /(bday|dob|birth|bdate|fec|na(cim)?)/.test(n)) return 'year';

  if (birthCtx) {
    if (/\b(mes|month|mois|monat|mese)\b/i.test(labelOnly) && !/(d(íi|i)a|day|jour|year|a(ñn)o|anno|jahr)/i.test(labelOnly)) return 'month';
    if (/(^|[^a-z])(d(íi|i)a|day|jour|tag)\b/i.test(labelOnly) && !/(mes|month|a(ñn)o|year|anno|jahr)/i.test(labelOnly)) return 'day';
    if (/(^|[^a-z])(a(ñn)o|year|jahr|anno|año|an(née|ee))\b/i.test(labelOnly) && !/(d(íi|i)a|day|mes|month)/i.test(labelOnly)) return 'year';
  }
  return null;
}

function pickRandomFromOptions(opts) {
  if (!opts.length) return null;
  const o = opts[randInt(0, opts.length - 1)];
  return o ? o.value : null;
}

function pickRandomBirthdaySelectValue(field, profile) {
  const matched = tryMatchProfileToBirthdaySelect(field, profile);
  if (matched != null) return matched;

  const usable = getUsableBirthdateOptions(field);
  if (usable.length === 0) return null;

  const part = classifyBirthdateSelectPart(field) ?? inferBirthSelectKindFromOptions(usable);
  // User want: koi bhi saal 2005 se *pehle* (< 2005) + koi bhi day
  const maxYExclusive = 2005;

  if (part === 'year') {
    const withY = [];
    for (const o of usable) {
      const y = getOptionAsYearNumber(o);
      if (!isNaN(y) && y >= 1800) {
        withY.push({ o, y });
      }
    }
    if (withY.length) {
      const before2005 = withY.filter((x) => x.y < maxYExclusive);
      if (before2005.length) {
        return pickRandomFromOptions(before2005.map((x) => x.o));
      }
      // Dropdown only 2005+ (rare for DOB) — pick smallest / oldest year
      withY.sort((a, b) => a.y - b.y);
      return withY[0].o.value;
    }
    return pickRandomFromOptions(usable);
  }

  if (part === 'day') {
    const dayOpts = usable.filter((o) => {
      const d = optionNumericHint(o);
      return !isNaN(d) && d >= 1 && d <= 31;
    });
    return pickRandomFromOptions(dayOpts.length ? dayOpts : usable);
  }

  if (part === 'month') {
    return pickRandomFromOptions(usable);
  }

  return pickRandomFromOptions(usable);
}

function getLabelText(field) {
  const ariaIds = field.getAttribute('aria-labelledby');
  if (ariaIds) {
    const chunks = [];
    for (const rawId of ariaIds.trim().split(/\s+/)) {
      if (!rawId) continue;
      try {
        const ref = document.getElementById(rawId);
        if (ref) chunks.push((ref.innerText || ref.textContent || '').trim());
      } catch (_) { /* invalid id */ }
    }
    if (chunks.some(Boolean)) return chunks.join(' ');
  }
  if (field.id) {
    const label = document.querySelector(`label[for="${CSS.escape(field.id)}"]`);
    if (label) return label.innerText || '';
  }
  const wrapped = field.closest('label');
  if (wrapped) return wrapped.innerText || '';
  // Look for preceding sibling label
  let prev = field.previousElementSibling;
  while (prev) {
    if (prev.tagName === 'LABEL' || prev.tagName === 'DT') return prev.innerText || '';
    prev = prev.previousElementSibling;
  }
  // XenForo / MUI / generic wrappers
  const row = field.closest(
    '.formRow, .inputGroup, .formButtonGroup, [class*="formRow"], [class*="inputGroup"], [class*="FormField"], [class*="form-field"], [class*="fieldRow"], .MuiFormControl-root, .MuiGrid-item, .MuiBox-root, [class*="InputWrapper"], [class*="input-wrapper"], dd, li'
  );
  if (row) {
    const l = row.querySelector(
      'label, dt, .formRow-title, legend, [class*="-label"]:not(input):not(textarea), [class*="Label"]:not(input):not(textarea), .MuiFormLabel-root, .MuiInputLabel-root, [class*="FloatingLabel"]'
    );
    if (l) return l.innerText || '';
    const bySuffix = row.querySelector('[id$="-label"], [id$="_label"]');
    if (bySuffix && bySuffix !== field) return bySuffix.innerText || '';
  }
  return '';
}

// ── Native value setter (works with React / Vue / Angular) ────────────────────

function setNativeValue(field, value) {
  if (!value && value !== 0) return;

  if (field.tagName === 'SELECT') {
    field.value = value;
    field.dispatchEvent(new Event('change', { bubbles: true }));
    return;
  }

  try {
    const proto   = field.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter  = Object.getOwnPropertyDescriptor(proto, 'value');
    if (setter && setter.set) {
      setter.set.call(field, value);
    } else {
      field.value = value;
    }
  } catch {
    field.value = value;
  }

  field.dispatchEvent(new Event('input',  { bubbles: true }));
  field.dispatchEvent(new Event('change', { bubbles: true }));
  field.dispatchEvent(new Event('blur',   { bubbles: true }));
}

// ── Security / secret questions (AI: same Groq or OpenAI key as comment AI) ─

function isSecurityQuestionField(field) {
  if (field.disabled) return false;
  if (String(field.value || '').trim()) return false;
  const tag = (field.tagName || '').toLowerCase();
  if (tag === 'textarea') {
    /* allow */
  } else if (tag === 'input') {
    const ty = (field.getAttribute('type') || 'text').toLowerCase();
    if (ty !== 'text' && ty !== 'search' && ty !== 'tel' && ty !== 'number') return false;
  } else {
    return false;
  }
  const label = (getLabelText(field) || '').toLowerCase();
  const n = [field.name, field.id, field.placeholder, field.getAttribute('aria-label') || '', label].join(' ').toLowerCase();
  const securityHint = /(security|secret|maiden|pet|childhood|mother|father|born|school|answer|question|book|movie|place|sicher|segur|geheim|antwort|pregunta|challenge|recovery|favo(u)?rite|custom|hint)/.test(n + ' ' + label);
  if (/(^|\b)(e[\s-]mail|password|captcha|phone|url|website|search|query)\b/.test(n) && !securityHint) {
    return false;
  }
  if (/\buser(name|_?id|_?login)\b/.test(n) && !securityHint) {
    return false;
  }
  if (/(security|secret( ?q(uestion)?| ?answer)?|challenge( ?q(uestion)?)?|mothers?[\s-]maiden|maiden( name| surname)?|first[\s-]pet|favo(u)?rite (book|film|movie|place|food)|childhood|city of birth|born (in|at)|name of (the )?school|sicher(heit|frage)?|geheim|pregunta( de)?\s*seg(uridad|ur)?|antwort( auf| zum| für)?|r(e|é)ponse( secr(è|e)te)?|answer (this|to| the|following)|custom[\s-]?q|custom question|hint( question)?|what (is|was) (the name|your))/.test(n + ' ' + label)) {
    return true;
  }
  const row = field.closest('tr, .formRow, li, .form-group, [class*="formRow"], fieldset, dd, .inputGroup, [class*="form-"]');
  if (row) {
    const rtxt = (row.innerText || '').toLowerCase().slice(0, 700);
    if (/(security|secret) ?(\(required\))?\s*(question|#|q\.?)|pregunta( de|)\s*segur|secret answer|challenge( question)?/i.test(rtxt) && (tag === 'textarea' || (field.getAttribute('type') || 'text').toLowerCase() === 'text' || (field.getAttribute('type') || 'text').toLowerCase() === 'search')) {
      if (/(e[\s-]mail|password|only)(?!.*answer)/.test((field.name || '') + (field.id || '')) && !/answer|secret|security|antwort/.test((field.name || '') + (field.id || ''))) {
        return false;
      }
      return true;
    }
  }
  return false;
}

function getSecurityQuestionBlockText(field) {
  const a = (field.name || '') + ' ' + (field.id || '') + ' ' + (field.placeholder || '');
  const lab = getLabelText(field) || '';
  const row = field.closest('tr, .formRow, li, dd, .form-group, [class*="formRow"], [class*="inputGroup"]');
  const extra = row ? (row.innerText || '').trim().slice(0, 800) : '';
  return (lab + '\n' + a + '\n' + extra).trim();
}

function fillSecurityQuestionsWithAI(settings, profile) {
  if (typeof fetchSecurityAnswerForQuestion !== 'function') return;
  (async function () {
    const nodes = document.querySelectorAll('input, textarea');
    const picked = [];
    for (const field of nodes) {
      if (isSecurityQuestionField(field)) {
        picked.push(field);
        if (picked.length >= 6) break;
      }
    }
    if (!picked.length) return;
    for (const field of picked) {
      if (String(field.value || '').trim()) continue;
      const block = getSecurityQuestionBlockText(field);
      if (block.length < 6) continue;
      const ans = await fetchSecurityAnswerForQuestion(settings, block);
      if (ans) {
        setNativeValue(field, ans);
        if (profile) currentProfile = profile;
      }
    }
  })();
}

// ── Scan (for debug / popup preview) ─────────────────────────────────────────

function scanFormFields() {
  const fields = [];
  document.querySelectorAll('input, textarea, select').forEach(f => {
    if (['hidden','submit','button','file','image','reset'].includes((f.type||'').toLowerCase())) return;
    fields.push({
      tag: f.tagName,
      type: f.type || '',
      name: f.name || '',
      id: f.id || '',
      placeholder: f.placeholder || '',
      label: getLabelText(f)
    });
  });
  return fields;
}

// ── Per-site auto-fill (register / login) ─────────────────────────────────────

let __autoFillDone = false;
let __pendingNewProfile = null;
let __lastHref = (typeof location !== 'undefined' && location.href) ? location.href : '';

function __noteLocationChange() {
  if (location.href !== __lastHref) {
    __lastHref = location.href;
    __autoFillDone = false;
    __pendingNewProfile = null;
  }
}

function hasPasswordFieldForFill() {
  return document.querySelectorAll('input[type="password"]:not([hidden]):not([disabled])').length > 0;
}

function getVisibleValueInputs() {
  return [...document.querySelectorAll('input:not([hidden])')].filter(
    f => {
      if (f.disabled) return false;
      const t = (f.type || 'text').toLowerCase();
      if (t === 'hidden' || t === 'submit' || t === 'button' || t === 'file' || t === 'image' || t === 'reset') return false;
      return true;
    }
  );
}

function hasEmailTypeOrAutocomplete() {
  if (document.querySelector('input[type="email"]:not([hidden]):not([disabled])')) return true;
  for (const f of document.querySelectorAll('input:not([hidden]):not([disabled])')) {
    const ac = (f.getAttribute('autocomplete') || '').toLowerCase();
    if (ac === 'email' || ac === 'username') return true;
  }
  return false;
}

function hasEmailLikeTextOrHiddenEmailField() {
  for (const sel of [
    'input[name="email" i]', 'input[id="email" i]', 'input[name*="mail" i]', 'input[name*="user" i]', 'input[id*="user" i]', 'input[name*="login" i]', 'input[name="user_email" i]', 'input[id="user_email" i]'
  ]) {
    const el = document.querySelector(sel);
    if (el && !el.disabled) return true;
  }
  for (const f of document.querySelectorAll('input[type="text"], input[type="search"]')) {
    if (f.disabled) continue;
    const a = (f.name + ' ' + f.id + ' ' + (f.placeholder || '') + ' ' + (f.getAttribute('aria-label') || '') + ' ' + (f.autocomplete || '')).toLowerCase();
    if (/(^|[^a-z])e[\-_ ]?mail|e_post|usermail|your[\s-]?email|correo( electr(ónico|onico))?\b|direcc(i(óo)?n) (de )?correo|login[\s-]?(id|name|email)/.test(a) && !/(^|[^a-z])search|(^|_)(q|s|kwp|keywords?)(\.|$|_)/i.test(a + ' ' + f.name + ' ' + f.id)) {
      return true;
    }
  }
  return false;
}

function pagePathOrTitleSuggestAuth() {
  const p = (location.pathname + ' ' + location.search).toLowerCase();
  if (/(^|\/)(register|regist(re|er|rarse|ro|rate)|foros?\/(register|regist)|sign-?up|signin|signup|log-?in|iniciar-?ses(ión|i[oó]n|ion)|crear-?cuenta|auth|join|create-?account|user\/(new|register|create)|account\/(new|create|register)|member|membership|subscribe|forgot|reset|wp-login|wp-?register|buddypress|u\/register|users\/)/.test(p) || p.includes('regist')) {
    return true;
  }
  const t = (document.title || '').toLowerCase();
  if (/(register|sign up|log in|create account|join|member|log[\s-]+on|sign[\s-]+in|reg(íi)?strate|registr(arse|o|ar)|iniciar ses(ión|i[oó]n|ion)|crear cuenta|con(é|e)ctate|cuenta nueva)/.test(t)) {
    return true;
  }
  return false;
}

function bodyTextSampleSuggestsAuth() {
  const b = (document.body && (document.body.innerText || '')) || '';
  const s = b.slice(0, 10000).toLowerCase();
  if (s.length < 20) return false;
  if (/(create (an? )?account|create your account|sign up|register (now|here|your)|log in|log[\s-]in|register below|new member|new account|choose (a |your )?password|confirm (your )?password|already have an account|join (us|our|the)|forgot( your)? password|username( or| &| and) password|registr(arse|o|aci(óo)n|ate|ation)?|crear( una)? cuenta|contraseñ|iniciar ses(ión|i[oó]n|ion))/.test(s)) {
    return true;
  }
  return false;
}

function formLooksLikeAuthOrRegister() {
  // Email-first signup steps (no password field yet) on clear register / join URLs
  if (
    !hasPasswordFieldForFill()
    && pagePathOrTitleSuggestAuth()
    && (hasEmailTypeOrAutocomplete() || hasEmailLikeTextOrHiddenEmailField())
  ) {
    return true;
  }

  if (!hasPasswordFieldForFill()) return false;
  if (hasEmailTypeOrAutocomplete()) return true;
  if (document.querySelector('input[autocomplete="new-password"]')) return true;
  if (hasEmailLikeTextOrHiddenEmailField()) return true;
  for (const form of document.querySelectorAll('form')) {
    if (!form.querySelector('input[type="password"]')) continue;
    const t = (form.innerText || '').toLowerCase().slice(0, 6000);
    if (/(log[\s-]*in|sign[\s-]*in|log[\s-]*on|registr(arse|o|ate|ation)?|register|reg(íi)?strate|sign[\s-]*up|create(\s+an?)?\s*account|join|password|pass(word)?|username|e[\s.-]*mail|user[\s-]*name|contraseñ|correo|ciudad|nick( name)?\b|apodo)/.test(t)) {
      return true;
    }
  }
  if (pagePathOrTitleSuggestAuth()) return true;
  if (bodyTextSampleSuggestsAuth() && (hasEmailTypeOrAutocomplete() || hasEmailLikeTextOrHiddenEmailField() || getVisibleValueInputs().length >= 2)) {
    return true;
  }
  // Long sign-up wizards: many text fields (was previously capped at 6, which blocked real forms)
  const visInputs = getVisibleValueInputs();
  if (visInputs.length >= 2 && visInputs.length <= 32) {
    const hasPwd = visInputs.some(f => f.type === 'password');
    const hasText = visInputs.some(f => f.type === 'text' || f.type === 'search');
    if (hasPwd && hasText) return true;
  }
  return false;
}

function hasPrefilledCredentialSignals() {
  try {
    const inputs = [...document.querySelectorAll('input:not([type="hidden"]):not([disabled]), textarea:not([disabled])')];
    if (!inputs.length) return false;

    const valued = inputs.filter((f) => safeInputValue(f).trim().length > 0);
    if (!valued.length) return false;

    let score = 0;
    for (const f of valued) {
      const t = safeInputType(f);
      const ac = (f.getAttribute('autocomplete') || '').toLowerCase();
      const n = ((f.name || '') + ' ' + (f.id || '') + ' ' + (f.placeholder || '') + ' ' + (f.getAttribute('aria-label') || '')).toLowerCase();

      // Strong signal: password is already present (browser-saved or site-remembered).
      if (t === 'password') return true;
      if (ac === 'current-password' || ac === 'password') return true;
      if (ac === 'username' || ac === 'email') score += 2;
      if (t === 'email') score += 2;
      if (/(user(name)?|login|e[\s._-]?mail|correo)/.test(n)) score += 1;

      // Chrome autofill often sets this pseudo class for remembered credentials.
      try {
        if (typeof f.matches === 'function' && f.matches(':-webkit-autofill')) score += 2;
      } catch (_) { /* ignore selector support errors */ }
    }

    // Typical remembered login: username/email plus at least one more credential-ish signal.
    if (score >= 3) return true;
    return false;
  } catch (_) {
    return false;
  }
}

function shouldSkipFillBecauseSavedCredentials() {
  if (!formLooksLikeAuthOrRegister()) return false;
  return hasPrefilledCredentialSignals();
}

function runAutoFillFromStorage() {
  if (location.protocol !== 'http:' && location.protocol !== 'https:') return;
  const host = location.hostname;
  if ((host === 'www.google.com' || host === 'google.com') && location.pathname.startsWith('/search')) {
    return;
  }
  storageLocalGet('accountAuthSession', (ga) => {
    if (!accountSessionSignedIn(ga.accountAuthSession)) return;
    runAutoFillFromStorageAuthed();
  });
}

function runAutoFillFromStorageAuthed() {
  __noteLocationChange();
  // Re-allow autofill on the same page if the user (or the site) cleared all password fields.
  if (__autoFillDone) {
    const pwdEls = [...document.querySelectorAll('input[type="password"]:not([hidden])')];
    const allPwdEmpty = pwdEls.length > 0 && pwdEls.every(p => !safeInputValue(p).trim());
    if (allPwdEmpty) {
      __autoFillDone = false;
    } else {
      return;
    }
  }
  if (!formLooksLikeAuthOrRegister()) return;
  if (shouldSkipFillBecauseSavedCredentials()) return;

  storageLocalGet(['settings', 'siteProfiles', 'autoFillOnPage'], data => {
    if (data.autoFillOnPage === false) return;
    const s = data.settings || {};
    const email = s.email;
    if (!email || !String(email).trim()) return;
    if (!formLooksLikeAuthOrRegister()) return;
    if (shouldSkipFillBecauseSavedCredentials()) return;

    const siteKey = normalizeSiteKey(location.hostname);
    const siteProfiles = Object.assign({}, data.siteProfiles || {});

    let profile = siteProfiles[siteKey];
    if (!profile) {
      if (!__pendingNewProfile) {
        __pendingNewProfile = generateProfile(email, s.website || '');
      }
      profile = __pendingNewProfile;
    } else {
      __pendingNewProfile = null;
    }

    profile = applySettingsEmailToProfile(profile, email);

    const filled = fillForm(profile);
    if (filled < 1) return;

    __autoFillDone = true;
    currentProfile = profile;
    siteProfiles[siteKey] = profile;
    storageLocalSetSafe({ siteProfiles, activeProfile: profile, activeProfileForSite: siteKey });
    setTimeout(() => { fillForm(profile); }, 500);
    setTimeout(() => { tryPostFillCaptchaAssist(); }, 800);
    setTimeout(() => { tryPostFillCaptchaAssist(); }, 2200);
    fillSecurityQuestionsWithAI(s, profile);
    setTimeout(() => fillSecurityQuestionsWithAI(s, profile), 2500);
  });
}

function startAutoFillWatcher() {
  if (location.protocol !== 'http:' && location.protocol !== 'https:') return;
  const host = location.hostname;
  if ((host === 'www.google.com' || host === 'google.com') && location.pathname.startsWith('/search')) {
    return;
  }

  // Run as soon as the watcher starts (storage read is async inside; no debounce on first pass).
  runAutoFillFromStorage();

  let t = 0;
  const debounced = () => {
    clearTimeout(t);
    t = setTimeout(() => {
      runAutoFillFromStorage();
    }, 90);
  };

  // Tight early retries for SPAs / late-mounted fields, then backoff.
  [0, 40, 90, 160, 280, 450, 700, 1400, 2500, 4000, 6000, 10000, 15000, 22000, 30000, 40000, 50000].forEach(ms => {
    setTimeout(debounced, ms);
  });

  const obs = new MutationObserver(() => {
    if (__autoFillDone) {
      obs.disconnect();
      return;
    }
    debounced();
  });
  const root = document.documentElement;
  if (root) {
    try {
      obs.observe(root, { childList: true, subtree: true, attributes: true, characterData: true });
    } catch (_) { /* */ }
  }
  setTimeout(() => { try { obs.disconnect(); } catch (_) { /* */ } }, 90000);

  // Foreground/visible tab: run immediately. Background tabs throttle setTimeout, so autofill used to
  // only run when the user came back to the register tab; this fires as soon as the tab is active.
  const runIfVisible = () => {
    if (document.visibilityState === 'visible') {
      runAutoFillFromStorage();
    }
  };
  document.addEventListener('visibilitychange', runIfVisible, { passive: true });
  window.addEventListener('pageshow', runIfVisible, { passive: true });
  window.addEventListener('focus', runIfVisible, { passive: true });
  runIfVisible();
  requestAnimationFrame(() => {
    requestAnimationFrame(runIfVisible);
  });
}

if (location.protocol === 'http:' || location.protocol === 'https:') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startAutoFillWatcher, { once: true });
  } else {
    startAutoFillWatcher();
  }
  const onClientRoute = () => {
    __noteLocationChange();
    runAutoFillFromStorage();
    setTimeout(() => { runAutoFillFromStorage(); }, 50);
    setTimeout(() => { runAutoFillFromStorage(); }, 200);
  };
  window.addEventListener('popstate', onClientRoute);
  (function wrapHistory() {
    const p = history.pushState;
    const r = history.replaceState;
    history.pushState = function wPush() {
      const o = p.apply(this, arguments);
      onClientRoute();
      return o;
    };
    history.replaceState = function wRep() {
      const o = r.apply(this, arguments);
      onClientRoute();
      return o;
    };
  })();
}

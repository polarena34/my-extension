// Shared helpers: per-site profile keys and hostname normalization
// (Used by content script and popup; keep in sync with one file.)

/**
 * @param {string} hostname
 * @returns {string}
 */
function normalizeSiteKey(hostname) {
  if (!hostname) return '';
  let h = String(hostname).toLowerCase();
  if (h.startsWith('www.')) h = h.slice(4);
  return h;
}
